import { Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { buttonClass, Kicker } from "@/components/site";

const frames = [
  {
    src: "/vehicles/xt-front.jpg",
    alt: "QORVEX X-T six-wheeler on a mountain track under a storm sky.",
    name: "X-T",
    slug: "x-t",
  },
  {
    src: "/vehicles/awk-exterior.jpg",
    alt: "AWK Soul hypercar on a racetrack in daylight.",
    name: "AWK Soul",
    slug: "awk-soul",
  },
  {
    src: "/vehicles/xt-rear.jpg",
    alt: "QORVEX X-T climbing desert rock at sunset.",
    name: "X-T",
    slug: "x-t",
  },
  {
    src: "/vehicles/awk-interior.jpg",
    alt: "AWK Soul carbon cockpit facing a circuit at sunset.",
    name: "AWK Soul",
    slug: "awk-soul",
  },
] as const;

export function Film() {
  const [index, setIndex] = useState(0);
  const [paused, setPaused] = useState(false);
  const frame = frames[index] ?? frames[0];

  useEffect(() => {
    if (paused) return;
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    const timer = window.setInterval(() => {
      setIndex((current) => (current + 1) % frames.length);
    }, 5600);
    return () => window.clearInterval(timer);
  }, [paused]);

  return (
    <section className="relative h-svh min-h-[36rem] overflow-hidden bg-ink" aria-label="QORVEX film">
      {frames.map((item, itemIndex) => (
        <img
          key={item.src}
          src={item.src}
          alt={itemIndex === index ? item.alt : ""}
          className={
            itemIndex === index
              ? "drift absolute inset-0 h-full w-full object-cover"
              : "absolute inset-0 h-full w-full object-cover opacity-0"
          }
        />
      ))}
      <div className="absolute inset-0 bg-gradient-to-t from-obsidian via-obsidian/25 to-obsidian/40" />
      <div className="absolute inset-0 bg-gradient-to-r from-obsidian/80 via-transparent to-transparent" />
      <div className="relative z-10 flex h-full flex-col justify-end px-5 pt-24 pb-16 sm:pb-20">
        <div className="mx-auto w-full max-w-7xl">
          <Kicker>QORVEX</Kicker>
          <h1 className="mt-4 max-w-3xl font-display text-6xl text-ivory sm:text-8xl">Born to Lead.</h1>
          <p className="mt-5 max-w-xl text-base text-ivory sm:text-lg">
            A short line. An electric grand tourer, an electric grand SUV, a six-wheel diesel, and a supercharged hypercar.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Link to="/collection" className={buttonClass("solid")}>
              Enter the collection
            </Link>
            <Link to="/about" className={buttonClass("ghost")}>
              The House
            </Link>
          </div>
          <div className="mt-10 flex flex-wrap items-center gap-4 text-xs tracking-widest uppercase">
            <Link to="/vehicles/$slug" params={{ slug: frame.slug }} className="text-champagne-2">
              Now showing · {frame.name}
            </Link>
            <div className="flex gap-2" role="tablist" aria-label="Film frames">
              {frames.map((item, itemIndex) => (
                <button
                  key={item.src}
                  type="button"
                  role="tab"
                  aria-selected={itemIndex === index}
                  aria-label={`Show ${item.name}`}
                  className={itemIndex === index ? "h-2 w-8 bg-ivory" : "h-2 w-4 bg-ivory/40"}
                  onClick={() => setIndex(itemIndex)}
                />
              ))}
            </div>
            <button type="button" className="min-h-11 text-muted" onClick={() => setPaused((value) => !value)}>
              {paused ? "Play film" : "Pause film"}
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
