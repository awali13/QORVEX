import { i as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, Z as require_react, b as Link, x as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as useServerFn, t as notifyDesk } from "./notify-TPvQyZQV.mjs";
import { c as Kicker, f as buttonClass, g as formatWhen, h as formatDuration, i as Route$2, l as Money, u as Note, v as holdRemaining } from "./router-CfsKt9Uf.mjs";
import { a as removeReservation, o as reservationPhase, t as getReservation } from "./reservations-DH_WAOy6.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/confirmation._ref-DnOG7q9r.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ConfirmationPage() {
	const { ref } = Route$2.useParams();
	const navigate = useNavigate();
	const send = useServerFn(notifyDesk);
	const [reservation, setReservation] = (0, import_react.useState)(void 0);
	const [now, setNow] = (0, import_react.useState)(() => Date.now());
	const [cancelling, setCancelling] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		setReservation(getReservation(ref) ?? null);
	}, [ref]);
	(0, import_react.useEffect)(() => {
		const timer = window.setInterval(() => setNow(Date.now()), 1e3);
		return () => window.clearInterval(timer);
	}, []);
	if (reservation === void 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "px-5 pt-32 text-muted",
		children: "Opening the reservation…"
	});
	if (!reservation) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-3xl px-5 pt-32 pb-24",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-5xl",
				children: "No reservation under that reference on this device."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-muted",
				children: "Reservations are stored in this browser, not in a shared account."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/reservations",
				className: "mt-6 inline-flex min-h-11 items-center text-xs tracking-widest text-champagne uppercase",
				children: "Your reservations"
			})
		]
	});
	const current = reservation;
	const phase = reservationPhase(current, now);
	const remaining = holdRemaining(current.createdAt, now);
	const opens = current.createdAt + 864e5;
	async function cancel() {
		setCancelling(true);
		try {
			await send({ data: {
				kind: "cancel",
				reference: current.reference,
				vehicleName: current.vehicleName,
				customerName: current.customer.fullName
			} });
		} catch {}
		removeReservation(current.reference);
		navigate({ to: "/reservations" });
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-3xl px-5 pt-28 pb-24",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Kicker, { children: ["Reservation ", reservation.reference] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-3 font-display text-5xl sm:text-6xl",
				children: phase === "holding" ? "The car is held." : phase === "open" ? "The purchase stage is open." : "Demonstration recorded."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-muted",
				children: phase === "holding" ? "A 24-hour waiting period is in force. Checkout stays closed until it ends. No payment has been taken." : phase === "open" ? "The hold has ended. You may open the demonstration checkout. It still does not take payment or place a factory order." : "A demonstration checkout was recorded on this device. No card was charged and no payment was received."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 border border-line p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs tracking-widest text-faint uppercase",
						children: "Status"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 font-display text-4xl",
						children: phase === "holding" ? formatDuration(remaining) : phase === "open" ? "Ready" : "Demonstration only"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted",
						children: phase === "holding" ? `Purchase stage opens ${formatWhen(opens)}.` : phase === "open" ? `The hold ended ${formatWhen(opens)}.` : `Recorded ${formatWhen(reservation.demoRecordedAt ?? now)}.`
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-8 space-y-3 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-3xl",
						children: "What you reserved"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: reservation.vehicleName }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-muted",
						children: reservation.configuration
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
						reservation.customer.fullName,
						" · ",
						reservation.customer.email,
						" · ",
						reservation.customer.phone
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-muted",
						children: [
							reservation.customer.address,
							", ",
							reservation.customer.city,
							", ",
							reservation.customer.country
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "space-y-1",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Vehicle estimate" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Money, { value: reservation.pricing.base })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Sample options" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Money, { value: reservation.pricing.options })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Delivery estimate" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Money, { value: reservation.pricing.delivery })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Registration estimate" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Money, { value: reservation.pricing.registration })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Documentation estimate" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Money, { value: reservation.pricing.documentation })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex justify-between border-t border-line pt-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Before local tax" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Money, { value: reservation.pricing.totalBeforeTax })]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-faint",
						children: "Local tax is not included. None of these amounts is a confirmed charge."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-3xl",
					children: "What happens next"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
					className: "mt-4 list-decimal space-y-3 pl-5 text-sm text-muted",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
							"The reservation is saved in this browser under ",
							reservation.reference,
							"."
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
							"For 24 hours from ",
							formatWhen(reservation.createdAt),
							" the purchase stage stays closed."
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "When the timer ends, demonstration checkout opens. It asks you to confirm details again and records a demonstration. It does not process a card." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "A real purchase would wait for a written confirmation from QORVEX after that hold. This preview cannot issue one." })
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-8",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Note, { children: [
					"WhatsApp: ",
					whatsAppCopy(reservation.whatsappBooking),
					" ",
					reservation.whatsappDetail
				] })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 flex flex-wrap gap-3",
				children: [
					phase === "open" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/checkout/$ref",
						params: { ref: reservation.reference },
						className: buttonClass("solid"),
						children: "Open demonstration checkout"
					}) : null,
					phase === "demonstration" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/checkout/$ref",
						params: { ref: reservation.reference },
						className: buttonClass("ghost"),
						children: "View demonstration record"
					}) : null,
					phase === "holding" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: buttonClass("ghost"),
						onClick: () => void cancel(),
						disabled: cancelling,
						children: cancelling ? "Cancelling…" : "Cancel this hold"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: buttonClass("ghost"),
						onClick: () => {
							removeReservation(reservation.reference);
							navigate({ to: "/reservations" });
						},
						children: "Remove from this device"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/reservations",
						className: buttonClass("ghost"),
						children: "All reservations"
					})
				]
			})
		]
	});
}
function whatsAppCopy(state) {
	if (state === "sent") return "Messages were accepted by the WhatsApp Business API.";
	if (state === "partial") return "Only some WhatsApp messages were accepted.";
	if (state === "not_configured") return "Not sent.";
	if (state === "rate_limited") return "Not sent — the desk is rate limited.";
	return "Not sent — the API call failed.";
}
//#endregion
export { ConfirmationPage as component };
