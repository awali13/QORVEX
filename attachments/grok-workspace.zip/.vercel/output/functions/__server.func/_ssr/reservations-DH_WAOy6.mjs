//#region node_modules/.nitro/vite/services/ssr/assets/reservations-DH_WAOy6.js
var RES_KEY = "qorvex.reservations.v1";
var ENQ_KEY = "qorvex.enquiries.v1";
function readList(key) {
	if (typeof localStorage === "undefined") return [];
	try {
		const raw = localStorage.getItem(key);
		if (!raw) return [];
		const parsed = JSON.parse(raw);
		return Array.isArray(parsed) ? parsed : [];
	} catch {
		return [];
	}
}
function writeList(key, list) {
	localStorage.setItem(key, JSON.stringify(list));
}
function listReservations() {
	return readList(RES_KEY).sort((a, b) => b.createdAt - a.createdAt);
}
function getReservation(reference) {
	return listReservations().find((item) => item.reference === reference);
}
function saveReservation(reservation) {
	const next = listReservations().filter((item) => item.reference !== reservation.reference);
	next.push(reservation);
	writeList(RES_KEY, next);
}
function removeReservation(reference) {
	writeList(RES_KEY, listReservations().filter((item) => item.reference !== reference));
}
function listEnquiries() {
	return readList(ENQ_KEY).sort((a, b) => b.createdAt - a.createdAt);
}
function saveEnquiry(enquiry) {
	const next = listEnquiries();
	next.push(enquiry);
	writeList(ENQ_KEY, next);
}
function makeReference() {
	const bytes = /* @__PURE__ */ new Uint8Array(4);
	crypto.getRandomValues(bytes);
	return `QVX-${Array.from(bytes, (byte) => byte.toString(16).padStart(2, "0")).join("").toUpperCase()}`;
}
function reservationPhase(reservation, now) {
	if (reservation.demoRecordedAt) return "demonstration";
	if (now < reservation.createdAt + 864e5) return "holding";
	return "open";
}
//#endregion
export { removeReservation as a, saveReservation as c, makeReference as i, listEnquiries as n, reservationPhase as o, listReservations as r, saveEnquiry as s, getReservation as t };
