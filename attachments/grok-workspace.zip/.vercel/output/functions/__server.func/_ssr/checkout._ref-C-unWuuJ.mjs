import { i as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, Z as require_react, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as useServerFn, t as notifyDesk } from "./notify-TPvQyZQV.mjs";
import { c as Kicker, f as buttonClass, g as formatWhen, h as formatDuration, l as Money, m as fieldClass, o as Route$4, s as Field, u as Note, v as holdRemaining } from "./router-CfsKt9Uf.mjs";
import { c as saveReservation, o as reservationPhase, t as getReservation } from "./reservations-DH_WAOy6.mjs";
import { r as validateCustomer } from "./validate-B75Uj1h4.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/checkout._ref-C-unWuuJ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var purchasePings = /* @__PURE__ */ new Set();
function CheckoutPage() {
	const { ref } = Route$4.useParams();
	const send = useServerFn(notifyDesk);
	const [reservation, setReservation] = (0, import_react.useState)(void 0);
	const [now, setNow] = (0, import_react.useState)(() => Date.now());
	const [customer, setCustomer] = (0, import_react.useState)(null);
	const [consent, setConsent] = (0, import_react.useState)(false);
	const [errors, setErrors] = (0, import_react.useState)({});
	const [pending, setPending] = (0, import_react.useState)(false);
	const [notice, setNotice] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		const found = getReservation(ref) ?? null;
		setReservation(found);
		setCustomer(found?.customer ?? null);
	}, [ref]);
	(0, import_react.useEffect)(() => {
		const timer = window.setInterval(() => setNow(Date.now()), 1e3);
		return () => window.clearInterval(timer);
	}, []);
	(0, import_react.useEffect)(() => {
		if (!reservation || reservation.purchaseNotified) return;
		if (reservationPhase(reservation, Date.now()) !== "open") return;
		if (purchasePings.has(reservation.reference)) return;
		purchasePings.add(reservation.reference);
		const current = reservation;
		(async () => {
			try {
				const result = await send({ data: {
					kind: "purchase",
					phase: "opened",
					reference: current.reference,
					vehicleName: current.vehicleName,
					totalBeforeTax: current.pricing.totalBeforeTax,
					customerName: current.customer.fullName
				} });
				const next = {
					...current,
					purchaseNotified: true,
					whatsappDetail: result.detail
				};
				saveReservation(next);
				setReservation(next);
			} catch {
				purchasePings.delete(current.reference);
				setNotice("Purchase-stage WhatsApp update did not send.");
			}
		})();
	}, [reservation, send]);
	if (reservation === void 0 || reservation && !customer) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "px-5 pt-32 text-muted",
		children: "Opening checkout…"
	});
	if (!reservation || !customer) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-3xl px-5 pt-32 pb-24",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-5xl",
			children: "Checkout needs a reservation on this device."
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/collection",
			className: "mt-6 inline-flex min-h-11 items-center text-champagne uppercase text-xs tracking-widest",
			children: "Collection"
		})]
	});
	if (reservationPhase(reservation, now) === "holding") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-3xl px-5 pt-28 pb-24",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: "Purchase stage closed" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-3 font-display text-5xl",
				children: "The 24-hour hold is still running."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 font-display text-4xl tabular-nums",
				children: formatDuration(holdRemaining(reservation.createdAt, now))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-4 text-muted",
				children: [
					"Checkout opens ",
					formatWhen(reservation.createdAt + 864e5),
					". The wait is part of the reservation, not a loading error."
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/confirmation/$ref",
				params: { ref: reservation.reference },
				className: `${buttonClass("solid")} mt-8`,
				children: "Back to the reservation"
			})
		]
	});
	function set(key, value) {
		setCustomer((current) => current ? {
			...current,
			[key]: value
		} : current);
	}
	async function onSubmit(event) {
		event.preventDefault();
		if (!customer || !reservation) return;
		const nextErrors = validateCustomer(customer, consent);
		setErrors(nextErrors);
		if (Object.keys(nextErrors).length || reservation.demoRecordedAt) return;
		setPending(true);
		let detail = "Demonstration saved on this device. WhatsApp update did not send.";
		try {
			detail = (await send({ data: {
				kind: "purchase",
				phase: "demo_recorded",
				reference: reservation.reference,
				vehicleName: reservation.vehicleName,
				totalBeforeTax: reservation.pricing.totalBeforeTax,
				customerName: customer.fullName.trim()
			} })).detail;
		} catch {
			detail = "Demonstration saved on this device. WhatsApp update did not send.";
		}
		const next = {
			...reservation,
			customer: {
				fullName: customer.fullName.trim(),
				email: customer.email.trim(),
				phone: customer.phone.trim(),
				country: customer.country.trim(),
				city: customer.city.trim(),
				address: customer.address.trim()
			},
			demoRecordedAt: Date.now(),
			purchaseNotified: true,
			whatsappDetail: detail
		};
		saveReservation(next);
		setReservation(next);
		setPending(false);
		setNotice("Demonstration recorded. No payment was received.");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto grid max-w-7xl gap-10 px-5 pt-28 pb-24 lg:grid-cols-12",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "lg:col-span-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: "Demonstration checkout" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-3 font-display text-5xl",
					children: "No payment is taken here."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-muted",
					children: "This screen records that you reviewed the reservation after the hold. It is not a payment processor, a card form, or a factory order."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Note, { children: "Card numbers are not requested and must not be typed into any field. If a message claims a payment was received, it is wrong — this preview cannot receive one." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 border border-line p-5 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs tracking-widest text-faint uppercase",
							children: reservation.reference
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-base",
							children: reservation.vehicleName
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-muted",
							children: reservation.configuration
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
							className: "mt-4 space-y-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
									label: "Vehicle estimate",
									value: reservation.pricing.base
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
									label: "Sample options",
									value: reservation.pricing.options
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
									label: "Delivery estimate",
									value: reservation.pricing.delivery
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
									label: "Registration estimate",
									value: reservation.pricing.registration
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
									label: "Documentation estimate",
									value: reservation.pricing.documentation
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "flex justify-between border-t border-line pt-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Before local tax" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Money, { value: reservation.pricing.totalBeforeTax })]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-faint",
							children: "Delivery, registration and documentation lines are sample estimates. Tax is excluded until a jurisdiction is confirmed by QORVEX. None of this is an official fee schedule."
						})
					]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "space-y-5 lg:col-span-7",
			onSubmit,
			noValidate: true,
			children: [
				reservation.demoRecordedAt ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Note, { children: [
					"Already recorded ",
					formatWhen(reservation.demoRecordedAt),
					". ",
					notice || reservation.whatsappDetail,
					" No payment was received."
				] }) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-5 sm:grid-cols-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							id: "fullName",
							label: "Full name",
							error: errors.fullName,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								id: "fullName",
								className: fieldClass,
								autoComplete: "name",
								value: customer.fullName,
								onChange: (event) => set("fullName", event.target.value)
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							id: "email",
							label: "Email",
							error: errors.email,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								id: "email",
								type: "email",
								className: fieldClass,
								autoComplete: "email",
								value: customer.email,
								onChange: (event) => set("email", event.target.value)
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							id: "phone",
							label: "Phone",
							error: errors.phone,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								id: "phone",
								type: "tel",
								className: fieldClass,
								autoComplete: "tel",
								value: customer.phone,
								onChange: (event) => set("phone", event.target.value)
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							id: "country",
							label: "Country",
							error: errors.country,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								id: "country",
								className: fieldClass,
								autoComplete: "country-name",
								value: customer.country,
								onChange: (event) => set("country", event.target.value)
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							id: "city",
							label: "City",
							error: errors.city,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								id: "city",
								className: fieldClass,
								autoComplete: "address-level2",
								value: customer.city,
								onChange: (event) => set("city", event.target.value)
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "sm:col-span-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								id: "address",
								label: "Delivery address",
								error: errors.address,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
									id: "address",
									rows: 3,
									className: fieldClass,
									autoComplete: "street-address",
									value: customer.address,
									onChange: (event) => set("address", event.target.value)
								})
							})
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex gap-3 text-sm text-muted",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "checkbox",
						className: "mt-1 size-4 accent-champagne",
						checked: consent,
						disabled: Boolean(reservation.demoRecordedAt),
						onChange: (event) => setConsent(event.target.checked)
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "I understand this demonstration checkout does not take payment and does not confirm a purchase." })]
				}),
				errors.consent ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-champagne-2",
					children: errors.consent
				}) : null,
				notice ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-champagne-2",
					children: notice
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "submit",
					className: buttonClass("solid"),
					disabled: pending || Boolean(reservation.demoRecordedAt),
					children: reservation.demoRecordedAt ? "Demonstration already recorded" : pending ? "Recording…" : "Record demonstration"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/confirmation/$ref",
					params: { ref: reservation.reference },
					className: "text-xs tracking-widest text-muted uppercase",
					children: "Return to reservation"
				}) })
			]
		})]
	});
}
function Line({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
		className: "flex justify-between gap-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Money, { value })]
	});
}
//#endregion
export { CheckoutPage as component };
