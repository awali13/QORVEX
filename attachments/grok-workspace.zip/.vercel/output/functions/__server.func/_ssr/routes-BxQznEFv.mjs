import { i as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, Z as require_react, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as Kicker, d as Reveal, f as buttonClass, y as vehicles } from "./router-CfsKt9Uf.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BxQznEFv.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var frames = [
	{
		src: "/vehicles/xt-front.jpg",
		alt: "QORVEX X-T six-wheeler on a mountain track under a storm sky.",
		name: "X-T",
		slug: "x-t"
	},
	{
		src: "/vehicles/awk-exterior.jpg",
		alt: "AWK Soul hypercar on a racetrack in daylight.",
		name: "AWK Soul",
		slug: "awk-soul"
	},
	{
		src: "/vehicles/xt-rear.jpg",
		alt: "QORVEX X-T climbing desert rock at sunset.",
		name: "X-T",
		slug: "x-t"
	},
	{
		src: "/vehicles/awk-interior.jpg",
		alt: "AWK Soul carbon cockpit facing a circuit at sunset.",
		name: "AWK Soul",
		slug: "awk-soul"
	}
];
function Film() {
	const [index, setIndex] = (0, import_react.useState)(0);
	const [paused, setPaused] = (0, import_react.useState)(false);
	const frame = frames[index] ?? frames[0];
	(0, import_react.useEffect)(() => {
		if (paused) return;
		if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
		const timer = window.setInterval(() => {
			setIndex((current) => (current + 1) % frames.length);
		}, 5600);
		return () => window.clearInterval(timer);
	}, [paused]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "relative h-svh min-h-[36rem] overflow-hidden bg-ink",
		"aria-label": "QORVEX film",
		children: [
			frames.map((item, itemIndex) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: item.src,
				alt: itemIndex === index ? item.alt : "",
				className: itemIndex === index ? "drift absolute inset-0 h-full w-full object-cover" : "absolute inset-0 h-full w-full object-cover opacity-0"
			}, item.src)),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-t from-obsidian via-obsidian/25 to-obsidian/40" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-r from-obsidian/80 via-transparent to-transparent" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "relative z-10 flex h-full flex-col justify-end px-5 pt-24 pb-16 sm:pb-20",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto w-full max-w-7xl",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: "QORVEX" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "mt-4 max-w-3xl font-display text-6xl text-ivory sm:text-8xl",
							children: "Born to Lead."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-5 max-w-xl text-base text-ivory sm:text-lg",
							children: "A short line. An electric grand tourer, an electric grand SUV, a six-wheel diesel, and a supercharged hypercar."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-8 flex flex-wrap gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/collection",
								className: buttonClass("solid"),
								children: "Enter the collection"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/about",
								className: buttonClass("ghost"),
								children: "The House"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-10 flex flex-wrap items-center gap-4 text-xs tracking-widest uppercase",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to: "/vehicles/$slug",
									params: { slug: frame.slug },
									className: "text-champagne-2",
									children: ["Now showing · ", frame.name]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex gap-2",
									role: "tablist",
									"aria-label": "Film frames",
									children: frames.map((item, itemIndex) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										role: "tab",
										"aria-selected": itemIndex === index,
										"aria-label": `Show ${item.name}`,
										className: itemIndex === index ? "h-2 w-8 bg-ivory" : "h-2 w-4 bg-ivory/40",
										onClick: () => setIndex(itemIndex)
									}, item.src))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "min-h-11 text-muted",
									onClick: () => setPaused((value) => !value),
									children: paused ? "Play film" : "Pause film"
								})
							]
						})
					]
				})
			})
		]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Film, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "mx-auto max-w-7xl px-5 py-20 md:py-28",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: "The line" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-4 max-w-3xl font-display text-5xl sm:text-6xl",
					children: "Four cars. Nothing else on the floor."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-6 max-w-2xl text-muted",
					children: "V9 and V09 are battery electric, with hydraulic fully active suspension. The X-T remains a V8 diesel 6×6. AWK Soul remains a supercharged V12 hypercar."
				})
			] })
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: vehicles.map((vehicle, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chapter, {
			vehicle,
			flip: index % 2 === 1
		}, vehicle.slug)) }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "border-t border-line",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto grid max-w-7xl gap-8 px-5 py-20 md:grid-cols-2 md:items-end",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: "Reservation" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-4 font-display text-5xl",
					children: "Hold the car for 24 hours."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-muted",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Choose a configuration, leave your details, and the purchase stage stays closed until the hold ends. Checkout on this site is a demonstration. No card is charged." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/collection",
						className: "mt-6 inline-flex min-h-11 items-center bg-ivory px-5 text-xs tracking-widest text-obsidian uppercase",
						children: "Choose a car"
					})]
				})]
			})
		})
	] });
}
function Chapter({ vehicle, flip }) {
	const shot = vehicle.shots[0];
	if (!shot) return null;
	const image = /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "bg-ink",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
			src: shot.src,
			alt: shot.alt,
			width: shot.width,
			height: shot.height,
			className: shot.frame === "banner" ? "mx-auto block h-auto w-full max-w-4xl object-contain" : "aspect-[3/2] h-full w-full object-cover"
		})
	});
	const copy = /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col justify-center px-5 py-10 md:px-10 md:py-16",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: vehicle.category }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "mt-3 font-display text-5xl",
				children: vehicle.name
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 font-display text-2xl text-champagne-2 italic",
				children: vehicle.epithet
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-5 text-muted",
				children: vehicle.summary
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6 flex flex-wrap gap-x-6 gap-y-2 text-sm",
				children: vehicle.specs.slice(0, 3).map((spec) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "block text-xs tracking-widest text-faint uppercase",
					children: spec.label
				}), spec.value] }, spec.label))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/vehicles/$slug",
				params: { slug: vehicle.slug },
				className: "mt-8 inline-flex min-h-11 items-center text-xs tracking-widest text-champagne-2 uppercase",
				children: ["View ", vehicle.code]
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("article", {
		className: "border-t border-line",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid md:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: flip ? "md:order-2" : void 0,
				children: image
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: flip ? "md:order-1" : void 0,
				children: copy
			})]
		})
	}) });
}
//#endregion
export { Home as component };
