import { C as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as Legal } from "./legal-DO_VN-Yl.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/refund-CX2M5-l5.js
var import_jsx_runtime = require_jsx_runtime();
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Legal, {
	title: "Refunds",
	children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "This website does not collect deposits, cards, or transfers. A demonstration checkout that says “recorded” has not received money. There is nothing for this preview to refund." }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Sample delivery, registration, documentation and vehicle prices are not charges. If a later, real QORVEX sale takes a deposit, the refund rule has to be the one in that sale’s reviewed terms — not this page." }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "If you typed card details anywhere despite the warning, treat them as exposed and contact your bank. The form is not a payment field and is not a secure card vault." })
	]
});
//#endregion
export { SplitComponent as component };
