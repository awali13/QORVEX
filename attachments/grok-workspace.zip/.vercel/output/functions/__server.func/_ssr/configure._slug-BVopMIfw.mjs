import { i as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, Z as require_react, x as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { _ as getVehicle, a as Route$3, c as Kicker, f as buttonClass, l as Money, p as cn, u as Note } from "./router-CfsKt9Uf.mjs";
import { i as writeConfig, n as quoteVehicle, r as readConfig } from "./pricing-BgasnRnJ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/configure._slug-BVopMIfw.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ConfigurePage() {
	const { slug } = Route$3.useParams();
	const vehicle = getVehicle(slug);
	if (!vehicle) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Configurator, { vehicle });
}
function Configurator({ vehicle }) {
	const navigate = useNavigate();
	const [config, setConfig] = (0, import_react.useState)(() => ({
		exteriorId: vehicle.exteriors[0]?.id ?? "",
		interiorId: vehicle.interiors[0]?.id ?? "",
		packageIds: []
	}));
	const [ready, setReady] = (0, import_react.useState)(false);
	const [showInterior, setShowInterior] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		setConfig(readConfig(vehicle));
		setReady(true);
	}, [vehicle]);
	(0, import_react.useEffect)(() => {
		if (ready) writeConfig(vehicle.slug, config);
	}, [
		config,
		ready,
		vehicle.slug
	]);
	const quote = (0, import_react.useMemo)(() => quoteVehicle(vehicle, config), [vehicle, config]);
	const exteriorShot = vehicle.shots.find((shot) => shot.view === "exterior") ?? vehicle.shots[0];
	const interiorShot = vehicle.shots.find((shot) => shot.view === "interior") ?? exteriorShot;
	const shot = showInterior ? interiorShot : exteriorShot;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto grid max-w-7xl gap-10 px-5 pt-28 pb-32 lg:grid-cols-12 lg:pb-20",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "lg:col-span-7",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: "Configure · sample choices" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-3 font-display text-5xl sm:text-6xl",
						children: vehicle.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-4 text-muted",
						children: [vehicle.epithet, ". The image does not recolour. It stays the reference study."]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-6 bg-ink",
						children: shot ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: shot.src,
							alt: shot.alt,
							width: shot.width,
							height: shot.height,
							className: shot.frame === "banner" ? "mx-auto block h-auto w-full max-w-4xl object-contain" : "aspect-[3/2] w-full object-cover"
						}) : null
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: cn("min-h-11 px-4 text-xs tracking-widest uppercase", !showInterior ? "bg-ivory text-obsidian" : "border border-line"),
							onClick: () => setShowInterior(false),
							children: "Exterior study"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: cn("min-h-11 px-4 text-xs tracking-widest uppercase", showInterior ? "bg-ivory text-obsidian" : "border border-line"),
							onClick: () => setShowInterior(true),
							children: "Interior study"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-6",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Note, { children: "Every colour, hide and package on this page is a sample choice. Only the reference finish has a photograph. Selecting another swatch changes the written configuration and the indicative price, not the picture." })
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "lg:col-span-5",
				onSubmit: (event) => {
					event.preventDefault();
					writeConfig(vehicle.slug, config);
					navigate({
						to: "/reserve/$slug",
						params: { slug: vehicle.slug }
					});
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
						className: "text-xs tracking-widest text-faint uppercase",
						children: "Exterior colour · sample"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 space-y-2",
						children: vehicle.exteriors.map((choice) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Swatch, {
							choice,
							name: "exterior",
							checked: config.exteriorId === choice.id,
							onChange: () => setConfig((current) => ({
								...current,
								exteriorId: choice.id
							}))
						}, choice.id))
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
						className: "mt-8",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
							className: "text-xs tracking-widest text-faint uppercase",
							children: "Interior · sample"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-3 space-y-2",
							children: vehicle.interiors.map((choice) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Swatch, {
								choice,
								name: "interior",
								checked: config.interiorId === choice.id,
								onChange: () => setConfig((current) => ({
									...current,
									interiorId: choice.id
								}))
							}, choice.id))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
						className: "mt-8",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
							className: "text-xs tracking-widest text-faint uppercase",
							children: "Packages · sample"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-3 space-y-2",
							children: vehicle.packages.map((choice) => {
								const checked = config.packageIds.includes(choice.id);
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "flex cursor-pointer gap-3 border border-line px-3 py-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "checkbox",
										className: "mt-1 size-4 accent-champagne",
										checked,
										onChange: () => setConfig((current) => ({
											...current,
											packageIds: checked ? current.packageIds.filter((id) => id !== choice.id) : [...current.packageIds, choice.id]
										}))
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "block",
											children: choice.name
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "block text-sm text-muted",
											children: choice.detail
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "mt-1 block text-sm tabular-nums text-champagne-2",
											children: ["+ ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Money, { value: choice.price })]
										})
									] })]
								}, choice.id);
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-8 border border-line bg-panel p-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs tracking-widest text-faint uppercase",
								children: "Indicative total before tax"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 font-display text-5xl",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Money, { value: quote.totalBeforeTax })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
								className: "mt-4 space-y-2 text-sm text-muted",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
										className: "flex justify-between gap-4",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Vehicle" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Money, { value: quote.base })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
										className: "flex justify-between gap-4",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Options" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Money, { value: quote.options })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
										className: "flex justify-between gap-4",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Delivery estimate" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Money, { value: quote.delivery })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
										className: "flex justify-between gap-4",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Registration estimate" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Money, { value: quote.registration })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
										className: "flex justify-between gap-4",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Documentation estimate" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Money, { value: quote.documentation })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
										className: "flex justify-between gap-4 text-ivory",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Before local tax" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Money, { value: quote.totalBeforeTax })]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-4 text-sm text-faint",
								children: "Local tax is not calculated. These fees are sample estimates, not confirmed QORVEX charges."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "submit",
								className: `${buttonClass("solid")} mt-6 w-full`,
								children: "Review reservation"
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-x-0 bottom-0 z-30 border-t border-line bg-obsidian/95 px-5 py-3 lg:hidden",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs tracking-widest text-faint uppercase",
						children: "Before tax"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-3xl",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Money, { value: quote.totalBeforeTax })
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: buttonClass("solid"),
						onClick: () => {
							writeConfig(vehicle.slug, config);
							navigate({
								to: "/reserve/$slug",
								params: { slug: vehicle.slug }
							});
						},
						children: "Review"
					})]
				})
			})
		]
	});
}
function Swatch({ choice, name, checked, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: cn("flex cursor-pointer items-center gap-3 border px-3 py-3", checked ? "border-champagne" : "border-line"),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				type: "radio",
				name,
				className: "sr-only",
				checked,
				onChange
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "size-11 shrink-0 border border-line",
				style: { background: choice.hex },
				"aria-hidden": true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "min-w-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "block",
					children: choice.name
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "block text-sm text-muted",
					children: choice.detail
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "ml-auto text-sm tabular-nums text-champagne-2",
				children: choice.price === 0 ? "Included" : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Money, { value: choice.price })
			})
		]
	});
}
//#endregion
export { ConfigurePage as component };
