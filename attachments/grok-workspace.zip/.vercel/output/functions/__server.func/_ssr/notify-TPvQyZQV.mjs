import { i as __toESM } from "../_runtime.mjs";
import { K as isRedirect, S as useRouter, Z as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { a as object, i as number, n as discriminatedUnion, o as string, r as literal, t as _enum } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/notify-TPvQyZQV.js
var import_react = /* @__PURE__ */ __toESM(require_react());
function useServerFn(serverFn) {
	const router = useRouter();
	return import_react.useCallback(async (...args) => {
		try {
			const res = await serverFn(...args);
			if (isRedirect(res)) throw res;
			return res;
		} catch (err) {
			if (isRedirect(err)) {
				err.options._fromLocation = router.stores.location.get();
				return router.navigate(router.resolveRedirect(err).options);
			}
			throw err;
		}
	}, [router, serverFn]);
}
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var customer = object({
	fullName: string().trim().min(2).max(120),
	email: string().trim().email().max(160),
	phone: string().trim().min(7).max(40),
	country: string().trim().min(2).max(80),
	city: string().trim().min(2).max(80),
	address: string().trim().min(8).max(240)
});
var payload = discriminatedUnion("kind", [
	object({
		kind: literal("reservation"),
		reference: string().trim().min(4).max(24),
		vehicleName: string().trim().min(2).max(80),
		configuration: string().trim().min(2).max(400),
		totalBeforeTax: number().int().nonnegative().max(2e7),
		customer
	}),
	object({
		kind: literal("cancel"),
		reference: string().trim().min(4).max(24),
		vehicleName: string().trim().min(2).max(80),
		customerName: string().trim().min(2).max(120)
	}),
	object({
		kind: literal("purchase"),
		phase: _enum(["opened", "demo_recorded"]),
		reference: string().trim().min(4).max(24),
		vehicleName: string().trim().min(2).max(80),
		totalBeforeTax: number().int().nonnegative().max(2e7),
		customerName: string().trim().min(2).max(120)
	}),
	object({
		kind: literal("enquiry"),
		name: string().trim().min(2).max(120),
		email: string().trim().email().max(160),
		phone: string().trim().min(7).max(40),
		topic: string().trim().min(2).max(80),
		vehicle: string().trim().max(80),
		message: string().trim().min(8).max(2e3)
	})
]);
var notifyDesk = createServerFn({ method: "POST" }).validator((input) => payload.parse(input)).handler(createSsrRpc("d0cd53ed69ed2e389529d87d46ac652dbe2aae0925e6fe02a268178880b512cf"));
//#endregion
export { useServerFn as n, notifyDesk as t };
