import { i as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, Z as require_react, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as ChevronLeft, r as ChevronRight } from "../_libs/lucide-react.mjs";
import { _ as getVehicle, c as Kicker, f as buttonClass, l as Money, n as Route, p as cn, u as Note } from "./router-CfsKt9Uf.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/vehicles._slug-BNGujSnJ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Gallery({ shots }) {
	const [view, setView] = (0, import_react.useState)("all");
	const filtered = view === "all" ? shots : shots.filter((shot) => shot.view === view);
	const [index, setIndex] = (0, import_react.useState)(0);
	const safe = filtered[Math.min(index, filtered.length - 1)] ?? shots[0];
	(0, import_react.useEffect)(() => {
		setIndex(0);
	}, [view]);
	if (!safe) return null;
	function step(delta) {
		setIndex((current) => {
			const count = filtered.length || 1;
			return (current + delta + count) % count;
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mb-4 flex flex-wrap gap-2",
			children: [
				"all",
				"exterior",
				"interior"
			].map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => setView(item),
				className: cn("min-h-11 px-4 text-xs tracking-widest uppercase", view === item ? "bg-ivory text-obsidian" : "border border-line text-muted"),
				children: item
			}, item))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative bg-ink",
			tabIndex: 0,
			role: "region",
			"aria-roledescription": "carousel",
			"aria-label": "Vehicle images",
			onKeyDown: (event) => {
				if (event.key === "ArrowRight") step(1);
				if (event.key === "ArrowLeft") step(-1);
			},
			children: [safe.frame === "banner" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: safe.src,
				alt: safe.alt,
				width: safe.width,
				height: safe.height,
				className: "mx-auto block h-auto w-full max-w-4xl object-contain"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: safe.src,
				alt: safe.alt,
				width: safe.width,
				height: safe.height,
				className: "aspect-[3/2] w-full object-cover"
			}), filtered.length > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "absolute top-1/2 left-3 inline-flex size-11 -translate-y-1/2 items-center justify-center bg-obsidian/80",
				onClick: () => step(-1),
				"aria-label": "Previous image",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-5" })
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "absolute top-1/2 right-3 inline-flex size-11 -translate-y-1/2 items-center justify-center bg-obsidian/80",
				onClick: () => step(1),
				"aria-label": "Next image",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-5" })
			})] }) : null]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-3 text-xs tracking-widest text-faint uppercase",
			children: [
				Math.min(index, filtered.length - 1) + 1,
				" / ",
				filtered.length,
				" · ",
				safe.view
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-4 flex gap-3 overflow-x-auto pb-1",
			children: filtered.map((shot, shotIndex) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
				className: "shrink-0",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setIndex(shotIndex),
					className: cn("block h-16 w-28 overflow-hidden border", shot.src === safe.src ? "border-champagne" : "border-line"),
					"aria-label": `Show image ${shotIndex + 1}`,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: shot.src,
						alt: "",
						className: "h-full w-full object-cover"
					})
				})
			}, shot.src))
		})
	] });
}
function VehiclePage() {
	const { slug } = Route.useParams();
	const vehicle = getVehicle(slug);
	if (!vehicle) return null;
	const hero = vehicle.shots[0];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "mx-auto max-w-7xl px-5 pt-24",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: vehicle.category }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-3 font-display text-5xl sm:text-7xl",
					children: vehicle.name
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 font-display text-3xl text-champagne-2 italic",
					children: vehicle.epithet
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-6 bg-ink",
			children: hero?.frame === "banner" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: hero.src,
				alt: hero.alt,
				width: hero.width,
				height: hero.height,
				className: "mx-auto block h-auto w-full max-w-4xl object-contain"
			}) : hero ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: hero.src,
				alt: hero.alt,
				width: hero.width,
				height: hero.height,
				className: "h-[58svh] w-full object-cover sm:h-[72svh]"
			}) : null
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid max-w-7xl gap-10 px-5 py-14 lg:grid-cols-12",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "lg:col-span-7",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "max-w-2xl text-muted",
					children: vehicle.story
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "border border-line bg-panel p-6 lg:col-span-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs tracking-widest text-faint uppercase",
						children: "Indicative price"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 font-display text-5xl",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Money, { value: vehicle.basePrice })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm text-muted",
						children: "Sample catalogue figure in USD, before options and before the sample delivery, registration and documentation estimates. Not a quote."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-6 flex flex-col gap-3 sm:flex-row",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/configure/$slug",
							params: { slug: vehicle.slug },
							className: buttonClass("solid"),
							children: "Configure"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/reserve/$slug",
							params: { slug: vehicle.slug },
							className: buttonClass("ghost"),
							children: "Reserve"
						})]
					})
				]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mx-auto max-w-7xl px-5 pb-16",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-4xl",
					children: "Gallery"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 max-w-2xl text-sm text-muted",
					children: "Original QORVEX studies only. Wide boards are shown in full, not cropped. Other colours do not change these photographs."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Gallery, { shots: vehicle.shots })
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "border-t border-line",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-7xl px-5 py-16",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-4xl",
						children: "Performance and specification"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
						className: "mt-8 grid gap-px bg-line sm:grid-cols-2 lg:grid-cols-4",
						children: vehicle.specs.map((spec) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "bg-obsidian px-4 py-5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-xs tracking-widest text-faint uppercase",
								children: spec.label
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "mt-2 text-lg",
								children: spec.value
							})]
						}, spec.label))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-10 grid gap-8 md:grid-cols-3",
						children: vehicle.highlights.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "font-display text-3xl",
							children: item.title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-sm text-muted",
							children: item.body
						})] }, item.title))
					})
				]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "border-t border-line",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-7xl px-5 py-16",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-4xl",
						children: "Configurations"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4 max-w-3xl",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Note, { children: "Exterior colours, interiors and packages below are sample choices for this preview. They are not a confirmed QORVEX option list. The photograph always shows the reference finish." })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-8 grid gap-8 md:grid-cols-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChoiceList, {
								title: "Exterior",
								items: vehicle.exteriors
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChoiceList, {
								title: "Interior",
								items: vehicle.interiors
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChoiceList, {
								title: "Packages",
								items: vehicle.packages
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/configure/$slug",
						params: { slug: vehicle.slug },
						className: `${buttonClass("solid")} mt-10`,
						children: "Build this car"
					})
				]
			})
		})
	] });
}
function ChoiceList({ title, items }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
		className: "text-xs tracking-widest text-faint uppercase",
		children: title
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "mt-4 space-y-4",
		children: items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
			className: "border-t border-line pt-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: item.name }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: item.detail
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm tabular-nums text-champagne-2",
					children: item.price === 0 ? "No sample premium" : `+ ${format(item.price)} sample`
				})
			]
		}, item.id))
	})] });
}
function format(value) {
	return new Intl.NumberFormat("en-US", {
		style: "currency",
		currency: "USD",
		maximumFractionDigits: 0
	}).format(value);
}
//#endregion
export { VehiclePage as component };
