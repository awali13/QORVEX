import { i as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, S as useRouter, X as notFound, Z as require_react, _ as lazyRouteComponent, b as Link, d as Scripts, f as HeadContent, g as Outlet, h as createRouter, p as useRouterState, v as createFileRoute, y as createRootRoute } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as Menu, t as X } from "../_libs/lucide-react.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { a as object, i as number, o as string, r as literal, s as union } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/site-Dv63HWVN.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var HOLD_MS = 864e5;
function formatMoney(value) {
	return new Intl.NumberFormat("en-US", {
		style: "currency",
		currency: "USD",
		maximumFractionDigits: 0
	}).format(value);
}
function holdRemaining(createdAt, now) {
	return Math.max(0, createdAt + HOLD_MS - now);
}
function formatDuration(ms) {
	const total = Math.ceil(ms / 1e3);
	const h = Math.floor(total / 3600);
	const m = Math.floor(total % 3600 / 60);
	const s = total % 60;
	return `${h}h ${String(m).padStart(2, "0")}m ${String(s).padStart(2, "0")}s`;
}
function formatWhen(ts) {
	return new Intl.DateTimeFormat("en-US", {
		dateStyle: "medium",
		timeStyle: "short"
	}).format(ts);
}
var sample = true;
var vehicles = [
	{
		slug: "v9",
		code: "V9",
		name: "QORVEX V9",
		category: "Luxury electric coupe",
		epithet: "Four-seater grand tourer",
		summary: "An electric grand tourer for four. Long bonnet, low roof, and a cabin finished for distance rather than display.",
		story: "The V9 is the house grand tourer. The supplied study shows a silver coupe with both cabin doors open onto four seats, a cashmere interior, and a calm, wide dash. Power, range and the chassis brief below are taken from the QORVEX model sheet and are not estimates.",
		basePrice: 268e3,
		fees: {
			delivery: 1800,
			registration: 750,
			documentation: 420
		},
		shots: [{
			src: "/vehicles/v9-exterior.jpg",
			alt: "Silver QORVEX V9 four-seater grand tourer coupe with doors open, photographed at night outside a glass house.",
			frame: "banner",
			view: "exterior",
			width: 799,
			height: 328
		}, {
			src: "/vehicles/v9-interior.jpg",
			alt: "QORVEX V9 front cabin in cashmere leather, with a wide display and a Q-marked steering wheel, at dusk.",
			frame: "banner",
			view: "interior",
			width: 729,
			height: 328
		}],
		specs: [
			{
				label: "Layout",
				value: "Four-seater grand tourer coupe",
				confirmed: true
			},
			{
				label: "Powertrain",
				value: "Battery electric",
				confirmed: true
			},
			{
				label: "Power",
				value: "620 hp",
				confirmed: true
			},
			{
				label: "Torque",
				value: "850 Nm",
				confirmed: true
			},
			{
				label: "Top speed",
				value: "270 km/h",
				confirmed: true
			},
			{
				label: "Range",
				value: "680 km",
				confirmed: true
			},
			{
				label: "Battery",
				value: "110 kWh",
				confirmed: true
			},
			{
				label: "Suspension",
				value: "Hydraulic fully active",
				confirmed: true
			}
		],
		highlights: [
			{
				title: "Grand touring, electric",
				body: "620 horsepower and 850 Nm, with a 110 kWh battery and a stated range of 680 km. Top speed is 270 km/h."
			},
			{
				title: "Active chassis",
				body: "Hydraulic fully active suspension is part of the V9 brief, aimed at keeping a low coupe composed on poor roads."
			},
			{
				title: "Four seats, two rows",
				body: "The reference film is titled as a four-seater grand tourer. The open-door study shows a cashmere cabin and a Q-marked wheel."
			}
		],
		exteriors: [
			{
				id: "liquid-silver",
				name: "Liquid silver",
				price: 0,
				sample,
				hex: "#c5c7cb",
				detail: "Reference finish in the supplied exterior study."
			},
			{
				id: "obsidian",
				name: "Obsidian",
				price: 0,
				sample,
				hex: "#141414",
				detail: "Sample colour. No separate photograph."
			},
			{
				id: "glacier",
				name: "Glacier",
				price: 1400,
				sample,
				hex: "#e6e1d8",
				detail: "Sample colour. No separate photograph."
			}
		],
		interiors: [{
			id: "cashmere",
			name: "Cashmere",
			price: 0,
			sample,
			hex: "#d7c6b0",
			detail: "Reference hide in the supplied cabin study."
		}, {
			id: "nocturne",
			name: "Nocturne black",
			price: 0,
			sample,
			hex: "#1a1a1a",
			detail: "Sample hide. No separate photograph."
		}],
		packages: [{
			id: "ppf",
			name: "Paint protection film",
			price: 4800,
			sample,
			detail: "Sample protection package. Not a confirmed factory fit."
		}, {
			id: "sills",
			name: "Illuminated treadplates",
			price: 740,
			sample,
			detail: "Sample trim. Not shown as standard in the study."
		}]
	},
	{
		slug: "v09",
		code: "V09",
		name: "QORVEX V09",
		category: "Luxury electric SUV",
		epithet: "Luxury grand SUV",
		summary: "A black grand SUV with an executive cabin: ivory leather, a full-width display, and screens for the rear seats.",
		story: "The V09 is the house grand SUV. Night studies show a dark body with a thin light signature, an ivory dash under a city skyline, and a rear cabin with entertainment screens. The performance figures below are from the model sheet.",
		basePrice: 242e3,
		fees: {
			delivery: 1900,
			registration: 750,
			documentation: 420
		},
		shots: [
			{
				src: "/vehicles/v09-exterior.jpg",
				alt: "Black QORVEX V09 luxury grand SUV on a wet terrace at night, with a light signature across the nose.",
				frame: "banner",
				view: "exterior",
				width: 800,
				height: 313
			},
			{
				src: "/vehicles/v09-dash.jpg",
				alt: "QORVEX V09 ivory dashboard at night, with a Q steering mark and a wide display facing a city skyline.",
				frame: "banner",
				view: "interior",
				width: 717,
				height: 313
			},
			{
				src: "/vehicles/v09-cabin.jpg",
				alt: "QORVEX V09 rear cabin in ivory leather, with screens on the front seatbacks, overlooking a night city.",
				frame: "banner",
				view: "interior",
				width: 1523,
				height: 370
			}
		],
		specs: [
			{
				label: "Layout",
				value: "Luxury grand SUV",
				confirmed: true
			},
			{
				label: "Powertrain",
				value: "Battery electric",
				confirmed: true
			},
			{
				label: "Power",
				value: "680 hp",
				confirmed: true
			},
			{
				label: "Torque",
				value: "920 Nm",
				confirmed: true
			},
			{
				label: "Top speed",
				value: "250 km/h",
				confirmed: true
			},
			{
				label: "Range",
				value: "650 km",
				confirmed: true
			},
			{
				label: "Battery",
				value: "120 kWh",
				confirmed: true
			},
			{
				label: "Suspension",
				value: "Hydraulic fully active",
				confirmed: true
			},
			{
				label: "Cabin",
				value: "Executive, front and rear seating",
				confirmed: true
			}
		],
		highlights: [
			{
				title: "The stronger electric SUV",
				body: "680 horsepower and 920 Nm, a 120 kWh battery, 650 km of stated range, and a top speed of 250 km/h."
			},
			{
				title: "Executive cabin",
				body: "Ivory leather, a continuous front display, and rear seatback screens are in the supplied interior studies. One cabin board carries the line “Beyond the ordinary.”"
			},
			{
				title: "Active chassis",
				body: "Hydraulic fully active suspension is specified for the V09, shared in principle with the V9 and tuned for the taller body."
			}
		],
		exteriors: [
			{
				id: "midnight",
				name: "Midnight black",
				price: 0,
				sample,
				hex: "#101114",
				detail: "Reference finish in the supplied exterior study."
			},
			{
				id: "graphite",
				name: "Graphite",
				price: 0,
				sample,
				hex: "#3c4046",
				detail: "Sample colour. No separate photograph."
			},
			{
				id: "pearl",
				name: "Pearl",
				price: 1600,
				sample,
				hex: "#efeae3",
				detail: "Sample colour. No separate photograph."
			}
		],
		interiors: [{
			id: "ivory",
			name: "Ivory executive",
			price: 0,
			sample,
			hex: "#e4d8c6",
			detail: "Reference cabin in the supplied studies."
		}, {
			id: "graphite-hide",
			name: "Graphite hide",
			price: 0,
			sample,
			hex: "#2a2a2a",
			detail: "Sample hide. No separate photograph."
		}],
		packages: [{
			id: "ambient",
			name: "Champagne ambient light",
			price: 1600,
			sample,
			detail: "Sample lighting theme. The studies already show a thin cabin light line."
		}, {
			id: "mats",
			name: "Executive floor set",
			price: 680,
			sample,
			detail: "Sample accessory. Not a confirmed factory option."
		}]
	},
	{
		slug: "x-t",
		code: "X-T",
		name: "QORVEX X-T",
		category: "Extreme 6×6 off-roader",
		epithet: "Six wheels, V8 diesel",
		summary: "A six-wheel expedition machine. V8 diesel, a winch and recovery gear, a roof light bar, and a five-seat tactical cabin.",
		story: "The X-T keeps the original V8 diesel brief and the six-wheel layout. The photographs show a protected dark body, front and rear winches, a roof rack with cases, and a black leather cabin with two command seats and a three-place rear bench. Output figures beyond that architecture were not in the written sheet supplied for this build, so any horsepower or range number is withheld rather than invented.",
		basePrice: 465e3,
		fees: {
			delivery: 4600,
			registration: 900,
			documentation: 640
		},
		shots: [
			{
				src: "/vehicles/xt-front.jpg",
				alt: "Dark QORVEX X-T six-wheel off-roader facing forward on a rocky mountain track at dusk, with a light bar and front winch.",
				frame: "poster",
				view: "exterior",
				width: 1529,
				height: 1028
			},
			{
				src: "/vehicles/xt-rear.jpg",
				alt: "QORVEX X-T six-wheeler seen from the rear three-quarter on red desert rock at sunset, with vertical tail lamps and a Q mark.",
				frame: "poster",
				view: "exterior",
				width: 1537,
				height: 1023
			},
			{
				src: "/vehicles/xt-interior.jpg",
				alt: "QORVEX X-T cabin in black leather, with a digital cluster, Q-marked wheel, and a three-place rear bench, doors open to mountains.",
				frame: "poster",
				view: "interior",
				width: 1536,
				height: 1024
			}
		],
		specs: [
			{
				label: "Layout",
				value: "6×6, three axles",
				confirmed: true
			},
			{
				label: "Powertrain",
				value: "V8 diesel",
				confirmed: true
			},
			{
				label: "Role",
				value: "Extreme off-roader",
				confirmed: true
			},
			{
				label: "Cabin",
				value: "Two command seats and a three-place rear bench",
				confirmed: true
			},
			{
				label: "Recovery",
				value: "Front and rear winch points, visible in the studies",
				confirmed: true
			},
			{
				label: "Roof",
				value: "Light bar and expedition cases",
				confirmed: true
			},
			{
				label: "Output",
				value: "Not stated in the supplied sheet — no sample horsepower is shown",
				confirmed: true
			}
		],
		highlights: [
			{
				title: "Six contact patches",
				body: "Three axles and six heavy off-road tyres. The stance is the point: ground clearance, approach, and a body that reads as equipment rather than trim."
			},
			{
				title: "V8 diesel",
				body: "The powertrain brief is a V8 diesel. Displacement, horsepower and torque are not restated here because they were not in the sheet supplied with this build."
			},
			{
				title: "Self-recovery",
				body: "Both the mountain study and the desert study show a winch, shackles, a roof light bar, and a loaded roof rack."
			}
		],
		exteriors: [
			{
				id: "stealth",
				name: "Stealth black",
				price: 0,
				sample,
				hex: "#1a1c1e",
				detail: "Reference finish in both exterior studies."
			},
			{
				id: "bronze",
				name: "Desert bronze",
				price: 2800,
				sample,
				hex: "#8a5a3c",
				detail: "Sample colour. No separate photograph."
			},
			{
				id: "rock",
				name: "Rock grey",
				price: 1800,
				sample,
				hex: "#6e6a65",
				detail: "Sample colour. No separate photograph."
			}
		],
		interiors: [{
			id: "command",
			name: "Command black",
			price: 0,
			sample,
			hex: "#171717",
			detail: "Reference cabin."
		}, {
			id: "sand",
			name: "Sand tactical",
			price: 1200,
			sample,
			hex: "#c2b39a",
			detail: "Sample hide. No separate photograph."
		}],
		packages: [{
			id: "recovery-kit",
			name: "Additional recovery kit",
			price: 1150,
			sample,
			detail: "Sample kit beyond the winches already visible."
		}, {
			id: "insulation",
			name: "Cabin insulation upgrade",
			price: 2900,
			sample,
			detail: "Sample comfort package. Not a confirmed factory fit."
		}]
	},
	{
		slug: "awk-soul",
		code: "AWK Soul",
		name: "AWK Soul",
		category: "Hypercar",
		epithet: "V12 supercharged",
		summary: "An exclusive two-seat hypercar. Supercharged V12 architecture, a carbon cockpit, and a body shaped for a circuit.",
		story: "AWK Soul is presented as the house hypercar. The brief keeps a supercharged V12. The studies show a black, low, winged car on a racetrack and a carbon cockpit with a sharply cut wheel. Numerical outputs were not in the supplied sheet, so they are not invented here.",
		basePrice: 215e4,
		fees: {
			delivery: 7200,
			registration: 1200,
			documentation: 880
		},
		shots: [{
			src: "/vehicles/awk-exterior.jpg",
			alt: "Black AWK Soul hypercar in profile on a racetrack, with a large rear wing, low nose, and yellow brake calipers.",
			frame: "poster",
			view: "exterior",
			width: 1536,
			height: 1024
		}, {
			src: "/vehicles/awk-interior.jpg",
			alt: "AWK Soul carbon cockpit at sunset, with a faceted steering wheel, digital cluster, and deeply bolstered seats.",
			frame: "poster",
			view: "interior",
			width: 1536,
			height: 1024
		}],
		specs: [
			{
				label: "Layout",
				value: "Two-seat hypercar",
				confirmed: true
			},
			{
				label: "Powertrain",
				value: "V12, supercharged",
				confirmed: true
			},
			{
				label: "Body",
				value: "Low coupe with a large rear wing",
				confirmed: true
			},
			{
				label: "Cockpit",
				value: "Carbon, circuit seating",
				confirmed: true
			},
			{
				label: "Output",
				value: "Not stated in the supplied sheet — no sample horsepower is shown",
				confirmed: true
			}
		],
		highlights: [
			{
				title: "Supercharged twelve",
				body: "The concept powertrain is a supercharged V12. Peak power, torque and top speed are omitted until a signed sheet exists. A made-up figure would be worse than a gap."
			},
			{
				title: "Circuit body",
				body: "The exterior study places the car on a track: long nose, cut surfaces, exposed mechanical detail at the wheels, and a full-width rear wing."
			},
			{
				title: "Carbon cockpit",
				body: "The interior study is a two-seat carbon cabin, a faceted wheel, and a low digital cluster, shot toward a circuit at sunset."
			}
		],
		exteriors: [{
			id: "jet",
			name: "Jet black",
			price: 0,
			sample,
			hex: "#0c0c0c",
			detail: "Reference finish in the track study."
		}, {
			id: "satin-carbon",
			name: "Satin carbon",
			price: 22e3,
			sample,
			hex: "#2b2b2b",
			detail: "Sample finish. No separate photograph."
		}],
		interiors: [{
			id: "carbon",
			name: "Carbon black",
			price: 0,
			sample,
			hex: "#141414",
			detail: "Reference cockpit."
		}, {
			id: "alcantara",
			name: "Alcantara insert",
			price: 8500,
			sample,
			hex: "#3a342f",
			detail: "Sample trim. Not a confirmed factory option."
		}],
		packages: [{
			id: "telemetry",
			name: "Circuit telemetry",
			price: 12e3,
			sample,
			detail: "Sample electronics package."
		}, {
			id: "mirrors",
			name: "Exposed carbon mirrors",
			price: 4200,
			sample,
			detail: "Sample exterior detail."
		}]
	}
];
function getVehicle(slug) {
	return vehicles.find((vehicle) => vehicle.slug === slug);
}
function Mark({ light = true }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: cn("inline-flex items-center gap-3", light ? "text-ivory" : "text-obsidian"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
			viewBox: "0 0 48 48",
			className: "size-8",
			"aria-hidden": "true",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "22",
				cy: "24",
				r: "11",
				fill: "none",
				stroke: "currentColor",
				strokeWidth: "1.7"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M28 31.5 L36 40",
				fill: "none",
				stroke: "currentColor",
				strokeWidth: "1.7"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-sm tracking-widest",
			children: "QORVEX"
		})]
	});
}
var links = [
	{
		to: "/collection",
		label: "Collection"
	},
	{
		to: "/about",
		label: "The House"
	},
	{
		to: "/enquiries",
		label: "Enquiries"
	},
	{
		to: "/reservations",
		label: "Reservations"
	}
];
function Header() {
	const pathname = useRouterState({ select: (state) => state.location.pathname });
	const [scrolled, setScrolled] = (0, import_react.useState)(false);
	const [open, setOpen] = (0, import_react.useState)(false);
	const solid = scrolled || pathname !== "/";
	(0, import_react.useEffect)(() => {
		const onScroll = () => setScrolled(window.scrollY > 12);
		onScroll();
		window.addEventListener("scroll", onScroll, { passive: true });
		return () => window.removeEventListener("scroll", onScroll);
	}, []);
	(0, import_react.useEffect)(() => {
		setOpen(false);
	}, [pathname]);
	(0, import_react.useEffect)(() => {
		document.body.style.overflow = open ? "hidden" : "";
		return () => {
			document.body.style.overflow = "";
		};
	}, [open]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: cn("fixed inset-x-0 top-0 z-40 transition-colors duration-200", solid || open ? "border-b border-line bg-obsidian/95" : "bg-transparent"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex h-16 max-w-7xl items-center justify-between gap-4 px-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/",
					"aria-label": "QORVEX home",
					className: "shrink-0",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, {})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					className: "hidden items-center gap-8 lg:flex",
					"aria-label": "Primary",
					children: links.map((link) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: link.to,
						className: cn("text-xs tracking-widest uppercase", pathname === link.to ? "text-champagne-2" : "text-ivory/80 hover:text-ivory"),
						children: link.label
					}, link.to))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/collection",
						className: cn(buttonClass("solid"), "hidden sm:inline-flex"),
						children: "Reserve"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "inline-flex size-11 items-center justify-center border border-line lg:hidden",
						"aria-expanded": open,
						"aria-controls": "mobile-nav",
						onClick: () => setOpen((value) => !value),
						children: [open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "size-5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "sr-only",
							children: open ? "Close menu" : "Open menu"
						})]
					})]
				})
			]
		}), open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
			id: "mobile-nav",
			className: "border-t border-line bg-obsidian px-5 py-6 lg:hidden",
			"aria-label": "Mobile",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
				className: "space-y-1",
				children: [
					links.map((link) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: link.to,
						className: "flex min-h-11 items-center text-lg font-display",
						children: link.label
					}) }, link.to)),
					vehicles.map((vehicle) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/vehicles/$slug",
						params: { slug: vehicle.slug },
						className: "flex min-h-11 items-center text-muted",
						children: vehicle.name
					}) }, vehicle.slug)),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
						className: "pt-3",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/collection",
							className: buttonClass("solid"),
							children: "Reserve a car"
						})
					})
				]
			})
		}) : null]
	});
}
function Footer() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
		className: "border-t border-line bg-ink",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid max-w-7xl gap-10 px-5 py-14 md:grid-cols-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "md:col-span-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, {}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 max-w-sm font-display text-3xl italic text-ivory",
							children: "Born to Lead."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 max-w-sm text-sm text-muted",
							children: "Four automobiles. Electric grand tourer, electric grand SUV, six-wheel diesel, supercharged hypercar."
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs tracking-widest uppercase text-faint",
					children: "Collection"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-4 space-y-2",
					children: vehicles.map((vehicle) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/vehicles/$slug",
						params: { slug: vehicle.slug },
						className: "text-sm text-ivory hover:text-champagne-2",
						children: vehicle.name
					}) }, vehicle.slug))
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs tracking-widest uppercase text-faint",
					children: "House"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "mt-4 space-y-2 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/about",
							className: "hover:text-champagne-2",
							children: "The House"
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/contact",
							className: "hover:text-champagne-2",
							children: "Contact"
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/enquiries",
							className: "hover:text-champagne-2",
							children: "Enquiries"
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/reservations",
							className: "hover:text-champagne-2",
							children: "Your reservations"
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/privacy",
							className: "hover:text-champagne-2",
							children: "Privacy"
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/terms",
							className: "hover:text-champagne-2",
							children: "Terms"
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/cancellation",
							className: "hover:text-champagne-2",
							children: "Cancellation"
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/refund",
							className: "hover:text-champagne-2",
							children: "Refunds"
						}) })
					]
				})] })
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "border-t border-line px-5 py-4 text-xs text-faint",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto flex max-w-7xl flex-col gap-2 sm:flex-row sm:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Prices in USD are indicative estimates for this preview. Not an offer." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Policies on this site are samples, not a reviewed contract." })]
			})
		})]
	});
}
function buttonClass(variant = "solid") {
	const base = "inline-flex min-h-11 items-center justify-center px-5 text-xs tracking-widest uppercase transition-transform duration-150 ease-out active:scale-[0.96] disabled:cursor-not-allowed disabled:opacity-50";
	if (variant === "ghost") return cn(base, "border border-ivory/30 text-ivory hover:border-champagne hover:text-champagne-2");
	if (variant === "line") return cn(base, "border-b border-champagne px-0 text-champagne-2 hover:text-ivory");
	return cn(base, "bg-ivory text-obsidian hover:bg-champagne-2");
}
function Note({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "border border-line bg-panel px-4 py-3 text-sm leading-relaxed text-muted",
		children
	});
}
function Kicker({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-xs tracking-widest uppercase text-champagne",
		children
	});
}
function Money({ value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "tabular-nums",
		children: formatMoney(value)
	});
}
function Field({ id, label, error, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block",
		htmlFor: id,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-xs tracking-widest uppercase text-faint",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-2",
				children
			}),
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				id: `${id}-error`,
				className: "mt-2 block text-sm text-champagne-2",
				children: error
			}) : null
		]
	});
}
var fieldClass = "w-full min-h-11 border border-line bg-ink px-3 text-sm text-ivory outline-none placeholder:text-faint focus:border-champagne";
function Reveal({ children, className }) {
	const [on, setOn] = (0, import_react.useState)(false);
	const [node, setNode] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		if (!node) return;
		if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
			setOn(true);
			return;
		}
		const observer = new IntersectionObserver(([entry]) => {
			if (entry?.isIntersecting) {
				setOn(true);
				observer.disconnect();
			}
		}, { threshold: .18 });
		observer.observe(node);
		return () => observer.disconnect();
	}, [node]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		ref: setNode,
		className: cn("reveal transition-[opacity,transform,filter] duration-700 ease-out", on ? "translate-y-0 opacity-100 blur-none" : "translate-y-3 opacity-0 blur-sm", className),
		children
	});
}
//#endregion
//#region node_modules/.nitro/vite/services/ssr/assets/router-CfsKt9Uf.js
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var FALLBACK_MESSAGE = "An unexpected error occurred. Try reloading the page.";
function errorMessage(error) {
	if (error instanceof Error && error.message) return error.message;
	if (typeof error === "string" && error) return error;
	return FALLBACK_MESSAGE;
}
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 bg-obsidian px-6 text-center text-ivory",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs tracking-widest text-champagne uppercase",
				children: "QORVEX"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-4xl",
				children: "Something went wrong"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-muted",
				children: errorMessage(error)
			})
		]
	});
}
/**
* Path-based preview hosts serve the dev server under `/{port_id}/` and strip
* that prefix before forwarding, so SSR sees `/` while the browser URL keeps the
* prefix. TanStack Start resets `basepath` on hydration, so a `rewrite` keeps
* client routing and generated links aligned with the public URL.
*/
var PATH_BASED_PREVIEW_HOSTS = /* @__PURE__ */ new Set([
	"preview.grok.genai.mil",
	"preview.grok.mil",
	"preview.grokgsac.com"
]);
var PORT_ID_PREFIX = /^\/hds-[a-z0-9]+-\d+-[a-z0-9]+(?=\/|$)/i;
function previewPathPrefix(hostname, pathname) {
	if (!PATH_BASED_PREVIEW_HOSTS.has(hostname.toLowerCase())) return void 0;
	return PORT_ID_PREFIX.exec(pathname)?.[0];
}
function prefixRewrite(prefix) {
	return {
		input: ({ url }) => {
			if (url.pathname === prefix) url.pathname = "/";
			else if (url.pathname.startsWith(`${prefix}/`)) url.pathname = url.pathname.slice(prefix.length);
			return url;
		},
		output: ({ url }) => {
			url.pathname = `${prefix}${url.pathname}`;
			return url;
		}
	};
}
function previewPathRewrite() {
	if (typeof window === "undefined") return void 0;
	const prefix = previewPathPrefix(window.location.hostname, window.location.pathname);
	return prefix ? prefixRewrite(prefix) : void 0;
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
var CONNECTOR_TOKEN_READY_EVENT = "grok:connector-token-ready";
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
var ConnectorTokenReadySchema = EnvelopeSchema.extend({ type: literal("connector-token-ready") });
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Origin of the Grok embedder framing this page, or null when the page runs
* top-level (download/export, local `npm run dev`, deployed sites) or under a
* non-Grok parent. Client-only; null during SSR.
*/
function resolveCurrentEmbedderOrigin() {
	if (typeof window === "undefined") return null;
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	return resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	const parentOrigin = resolveCurrentEmbedderOrigin();
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onHello = (data) => {
		if (!HelloSchema.safeParse(data).success) return;
		announce();
	};
	const onNavigate = (data) => {
		const parsed = NavigateSchema.safeParse(data);
		if (!parsed.success) return;
		navigate(parsed.data.path);
		queueMicrotask(reportLocation);
	};
	const onHistory = (data) => {
		const parsed = HistorySchema.safeParse(data);
		if (!parsed.success) return;
		if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
		window.history.go(parsed.data.delta);
	};
	const onConnectorTokenReady = (data) => {
		if (!ConnectorTokenReadySchema.safeParse(data).success) return;
		window.dispatchEvent(new Event(CONNECTOR_TOKEN_READY_EVENT));
	};
	const hostMessageHandlers = /* @__PURE__ */ new Map([
		["hello", onHello],
		["navigate", onNavigate],
		["history", onHistory],
		["connector-token-ready", onConnectorTokenReady]
	]);
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		hostMessageHandlers.get(envelope.data.type)?.(event.data);
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
var styles_default = "/assets/styles-BujosX3R.css";
var Route$15 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: "QORVEX — Born to Lead" },
			{
				name: "description",
				content: "QORVEX automobiles: V9 electric grand tourer, V09 electric grand SUV, X-T 6×6 diesel, and AWK Soul hypercar."
			},
			{
				name: "theme-color",
				content: "#0c0b0a"
			}
		],
		links: [
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,500;0,600;1,500&family=Outfit:wght@300;400;500;600&display=swap"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			}
		]
	}),
	component: RootComponent,
	notFoundComponent: NotFound
});
function RootComponent() {
	const pathname = useRouterState({ select: (state) => state.location.pathname });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AuthProvider, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: "#content",
					className: "sr-only focus:not-sr-only focus:absolute focus:z-50 focus:bg-ivory focus:px-3 focus:py-2 focus:text-obsidian",
					children: "Skip to content"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Header, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
					id: "content",
					className: "page-enter min-h-svh",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {})
				}, pathname),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Footer, {})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
		] })]
	});
}
function NotFound() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-3xl px-5 pt-32 pb-24",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs tracking-widest uppercase text-champagne",
				children: "404"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-3 font-display text-5xl",
				children: "This page is not in the collection."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-muted",
				children: "The address does not match a QORVEX page."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/",
				className: "mt-8 inline-flex min-h-11 items-center text-xs tracking-widest uppercase text-champagne-2",
				children: "Return home"
			})
		]
	});
}
var $$splitComponentImporter$14 = () => import("./routes-BxQznEFv.mjs");
var Route$14 = createFileRoute("/")({ component: lazyRouteComponent($$splitComponentImporter$14, "component") });
var $$splitComponentImporter$13 = () => import("./about-Cvg7ZgSS.mjs");
var Route$13 = createFileRoute("/about")({
	head: () => ({ meta: [{ title: "The House — QORVEX" }] }),
	component: lazyRouteComponent($$splitComponentImporter$13, "component")
});
var $$splitComponentImporter$12 = () => import("./cancellation-GbLf3I-g.mjs");
var Route$12 = createFileRoute("/cancellation")({
	head: () => ({ meta: [{ title: "Cancellation — QORVEX" }] }),
	component: lazyRouteComponent($$splitComponentImporter$12, "component")
});
var $$splitComponentImporter$11 = () => import("./collection-qz1j4REg.mjs");
var Route$11 = createFileRoute("/collection")({
	head: () => ({ meta: [{ title: "Collection — QORVEX" }] }),
	component: lazyRouteComponent($$splitComponentImporter$11, "component")
});
var $$splitComponentImporter$10 = () => import("./contact-DM0xzQkE.mjs");
var Route$10 = createFileRoute("/contact")({
	head: () => ({ meta: [{ title: "Contact — QORVEX" }] }),
	component: lazyRouteComponent($$splitComponentImporter$10, "component")
});
var $$splitComponentImporter$9 = () => import("./enquiries-Dv1Ny9xI.mjs");
var Route$9 = createFileRoute("/enquiries")({
	head: () => ({ meta: [{ title: "Enquiries — QORVEX" }] }),
	component: lazyRouteComponent($$splitComponentImporter$9, "component")
});
var $$splitComponentImporter$8 = () => import("./privacy-LSQoNtJA.mjs");
var Route$8 = createFileRoute("/privacy")({
	head: () => ({ meta: [{ title: "Privacy — QORVEX" }] }),
	component: lazyRouteComponent($$splitComponentImporter$8, "component")
});
var $$splitComponentImporter$7 = () => import("./refund-CX2M5-l5.mjs");
var Route$7 = createFileRoute("/refund")({
	head: () => ({ meta: [{ title: "Refunds — QORVEX" }] }),
	component: lazyRouteComponent($$splitComponentImporter$7, "component")
});
var $$splitComponentImporter$6 = () => import("./reservations-Bb2_bggi.mjs");
var Route$6 = createFileRoute("/reservations")({
	head: () => ({ meta: [{ title: "Reservations — QORVEX" }] }),
	component: lazyRouteComponent($$splitComponentImporter$6, "component")
});
var $$splitComponentImporter$5 = () => import("./terms-B-PJeHPB.mjs");
var Route$5 = createFileRoute("/terms")({
	head: () => ({ meta: [{ title: "Terms — QORVEX" }] }),
	component: lazyRouteComponent($$splitComponentImporter$5, "component")
});
var $$splitComponentImporter$4 = () => import("./checkout._ref-C-unWuuJ.mjs");
var Route$4 = createFileRoute("/checkout/$ref")({
	head: () => ({ meta: [{ title: "Demonstration checkout — QORVEX" }] }),
	component: lazyRouteComponent($$splitComponentImporter$4, "component")
});
var $$splitComponentImporter$3 = () => import("./configure._slug-BVopMIfw.mjs");
var Route$3 = createFileRoute("/configure/$slug")({
	loader: ({ params }) => {
		if (!getVehicle(params.slug)) throw notFound();
		return { slug: params.slug };
	},
	head: ({ params }) => {
		const vehicle = getVehicle(params.slug);
		return { meta: [{ title: vehicle ? `Configure ${vehicle.code} — QORVEX` : "Configure — QORVEX" }] };
	},
	component: lazyRouteComponent($$splitComponentImporter$3, "component")
});
var $$splitComponentImporter$2 = () => import("./confirmation._ref-DnOG7q9r.mjs");
var Route$2 = createFileRoute("/confirmation/$ref")({
	head: () => ({ meta: [{ title: "Reservation — QORVEX" }] }),
	component: lazyRouteComponent($$splitComponentImporter$2, "component")
});
var $$splitComponentImporter$1 = () => import("./reserve._slug-D-bgJzKm.mjs");
var Route$1 = createFileRoute("/reserve/$slug")({
	loader: ({ params }) => {
		if (!getVehicle(params.slug)) throw notFound();
		return { slug: params.slug };
	},
	head: () => ({ meta: [{ title: "Reserve — QORVEX" }] }),
	component: lazyRouteComponent($$splitComponentImporter$1, "component")
});
var $$splitNotFoundComponentImporter = () => import("./vehicles._slug-Dw920bY9.mjs");
var $$splitComponentImporter = () => import("./vehicles._slug-BNGujSnJ.mjs");
var Route = createFileRoute("/vehicles/$slug")({
	loader: ({ params }) => {
		const vehicle = getVehicle(params.slug);
		if (!vehicle) throw notFound();
		return { slug: vehicle.slug };
	},
	head: ({ params }) => {
		const vehicle = getVehicle(params.slug);
		return { meta: [{ title: vehicle ? `${vehicle.name} — QORVEX` : "QORVEX" }] };
	},
	component: lazyRouteComponent($$splitComponentImporter, "component"),
	notFoundComponent: lazyRouteComponent($$splitNotFoundComponentImporter, "notFoundComponent")
});
var rootRouteChildren = {
	IndexRoute: Route$14.update({
		id: "/",
		path: "/",
		getParentRoute: () => Route$15
	}),
	AboutRoute: Route$13.update({
		id: "/about",
		path: "/about",
		getParentRoute: () => Route$15
	}),
	CancellationRoute: Route$12.update({
		id: "/cancellation",
		path: "/cancellation",
		getParentRoute: () => Route$15
	}),
	CollectionRoute: Route$11.update({
		id: "/collection",
		path: "/collection",
		getParentRoute: () => Route$15
	}),
	ContactRoute: Route$10.update({
		id: "/contact",
		path: "/contact",
		getParentRoute: () => Route$15
	}),
	EnquiriesRoute: Route$9.update({
		id: "/enquiries",
		path: "/enquiries",
		getParentRoute: () => Route$15
	}),
	PrivacyRoute: Route$8.update({
		id: "/privacy",
		path: "/privacy",
		getParentRoute: () => Route$15
	}),
	RefundRoute: Route$7.update({
		id: "/refund",
		path: "/refund",
		getParentRoute: () => Route$15
	}),
	ReservationsRoute: Route$6.update({
		id: "/reservations",
		path: "/reservations",
		getParentRoute: () => Route$15
	}),
	TermsRoute: Route$5.update({
		id: "/terms",
		path: "/terms",
		getParentRoute: () => Route$15
	}),
	CheckoutRefRoute: Route$4.update({
		id: "/checkout/$ref",
		path: "/checkout/$ref",
		getParentRoute: () => Route$15
	}),
	ConfigureSlugRoute: Route$3.update({
		id: "/configure/$slug",
		path: "/configure/$slug",
		getParentRoute: () => Route$15
	}),
	ConfirmationRefRoute: Route$2.update({
		id: "/confirmation/$ref",
		path: "/confirmation/$ref",
		getParentRoute: () => Route$15
	}),
	ReserveSlugRoute: Route$1.update({
		id: "/reserve/$slug",
		path: "/reserve/$slug",
		getParentRoute: () => Route$15
	}),
	VehiclesSlugRoute: Route.update({
		id: "/vehicles/$slug",
		path: "/vehicles/$slug",
		getParentRoute: () => Route$15
	})
};
var routeTree = Route$15._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		rewrite: previewPathRewrite(),
		defaultErrorComponent: AppErrorComponent,
		scrollRestoration: true
	});
}
//#endregion
export { getVehicle as _, Route$3 as a, Kicker as c, Reveal as d, buttonClass as f, formatWhen as g, formatDuration as h, Route$2 as i, Money as l, fieldClass as m, Route as n, Route$4 as o, cn as p, Route$1 as r, Field as s, router_exports as t, Note as u, holdRemaining as v, vehicles as y };
