import { C as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as Legal } from "./legal-DO_VN-Yl.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/cancellation-GbLf3I-g.js
var import_jsx_runtime = require_jsx_runtime();
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Legal, {
	title: "Cancellation",
	children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "During the 24-hour hold you can cancel from the reservation page. Cancellation deletes the reservation from this browser and attempts a WhatsApp update if the Business Platform is configured. Because no money is taken, cancellation does not create a refund." }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "After the hold, you can remove a demonstration record from this device. That does not unwind a purchase, because this preview never makes one." }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "A future QORVEX contract would need its own cancellation window, written in the currency and law of the sale. This page is not that contract." })
	]
});
//#endregion
export { SplitComponent as component };
