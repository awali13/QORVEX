import { C as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as Legal } from "./legal-DO_VN-Yl.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/terms-B-PJeHPB.js
var import_jsx_runtime = require_jsx_runtime();
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Legal, {
	title: "Terms",
	children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Using this preview does not create a contract to buy a car. Indicative prices, sample colours, sample packages, and sample delivery, registration and documentation figures are illustrations. They are not an offer, an invoice, or a confirmed fee." }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Specifications labelled on the V9 and V09 as power, torque, top speed, range, battery and suspension follow the model sheet used to build this site. The X-T is described as a V8 diesel 6×6. AWK Soul is described as a supercharged V12 hypercar. Figures that were not in that sheet are not filled in." }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "A reservation starts a 24-hour waiting period measured from the server time returned when you submit. Until that period ends, demonstration checkout stays closed. After it ends, checkout only records a demonstration. No payment is collected, and no factory build slot is promised." }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Photographs remain the reference studies supplied with the site. A swatch that is not the photographed finish does not represent a manufactured colour that QORVEX has confirmed." })
	]
});
//#endregion
export { SplitComponent as component };
