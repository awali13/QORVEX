import { i as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, Z as require_react, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as Kicker, h as formatDuration, l as Money, v as holdRemaining } from "./router-CfsKt9Uf.mjs";
import { o as reservationPhase, r as listReservations } from "./reservations-DH_WAOy6.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/reservations-Bb2_bggi.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ReservationsPage() {
	const [items, setItems] = (0, import_react.useState)(null);
	const [now, setNow] = (0, import_react.useState)(() => Date.now());
	(0, import_react.useEffect)(() => {
		setItems(listReservations());
		const timer = window.setInterval(() => setNow(Date.now()), 1e3);
		return () => window.clearInterval(timer);
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-3xl px-5 pt-28 pb-24",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: "This device" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-3 font-display text-5xl sm:text-6xl",
				children: "Your reservations."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-muted",
				children: "Stored in this browser only. Clearing site data removes them. They are not an account and not a paid order."
			}),
			items === null ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-8 text-sm text-faint",
				children: "Loading…"
			}) : null,
			items && items.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-10 text-muted",
				children: [
					"None yet.",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/collection",
						className: "text-champagne-2",
						children: "Choose a car"
					}),
					"."
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-10 space-y-6",
				children: items?.map((item) => {
					const phase = reservationPhase(item, now);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "border border-line p-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs tracking-widest text-faint uppercase",
								children: item.reference
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mt-2 font-display text-4xl",
								children: item.vehicleName
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-muted",
								children: item.configuration
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-sm",
								children: phase === "holding" ? `Hold · ${formatDuration(holdRemaining(item.createdAt, now))} left` : phase === "open" ? "Purchase stage open · demonstration checkout" : "Demonstration recorded · no payment"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-1 text-sm tabular-nums",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Money, { value: item.pricing.totalBeforeTax }), " before tax, indicative"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-4 flex flex-wrap gap-4 text-xs tracking-widest uppercase",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/confirmation/$ref",
									params: { ref: item.reference },
									className: "text-champagne-2",
									children: "Details"
								}), phase !== "holding" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/checkout/$ref",
									params: { ref: item.reference },
									className: "text-champagne-2",
									children: "Checkout"
								}) : null]
							})
						]
					}, item.reference);
				})
			})
		]
	});
}
//#endregion
export { ReservationsPage as component };
