import { C as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as EnquiryDesk } from "./enquiry-desk-Cwb3oxLc.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/enquiries-Dv1Ny9xI.js
var import_jsx_runtime = require_jsx_runtime();
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EnquiryDesk, {
	heading: "Ask the house.",
	lede: "Questions about a model, a reservation, or ownership. This desk does not start the 24-hour hold — use Reserve on the car for that."
});
//#endregion
export { SplitComponent as component };
