//#region node_modules/.nitro/vite/services/ssr/assets/pricing-BgasnRnJ.js
function defaultConfig(vehicle) {
	return {
		exteriorId: vehicle.exteriors[0]?.id ?? "",
		interiorId: vehicle.interiors[0]?.id ?? "",
		packageIds: []
	};
}
function sanitizeConfig(vehicle, raw) {
	const fallback = defaultConfig(vehicle);
	if (!raw) return fallback;
	return {
		exteriorId: vehicle.exteriors.some((item) => item.id === raw.exteriorId) ? raw.exteriorId : fallback.exteriorId,
		interiorId: vehicle.interiors.some((item) => item.id === raw.interiorId) ? raw.interiorId : fallback.interiorId,
		packageIds: Array.isArray(raw.packageIds) ? raw.packageIds.filter((id) => vehicle.packages.some((item) => item.id === id)) : []
	};
}
var storageKey = (slug) => `qorvex.config.${slug}`;
function readConfig(vehicle) {
	if (typeof sessionStorage === "undefined") return defaultConfig(vehicle);
	try {
		const raw = sessionStorage.getItem(storageKey(vehicle.slug));
		if (!raw) return defaultConfig(vehicle);
		return sanitizeConfig(vehicle, JSON.parse(raw));
	} catch {
		return defaultConfig(vehicle);
	}
}
function writeConfig(slug, config) {
	if (typeof sessionStorage === "undefined") return;
	sessionStorage.setItem(storageKey(slug), JSON.stringify(config));
}
function quoteVehicle(vehicle, config) {
	const safe = sanitizeConfig(vehicle, config);
	const exterior = vehicle.exteriors.find((item) => item.id === safe.exteriorId) ?? vehicle.exteriors[0];
	const interior = vehicle.interiors.find((item) => item.id === safe.interiorId) ?? vehicle.interiors[0];
	const packages = vehicle.packages.filter((item) => safe.packageIds.includes(item.id));
	const options = exterior.price + interior.price + packages.reduce((sum, item) => sum + item.price, 0);
	const { delivery, registration, documentation } = vehicle.fees;
	return {
		exterior,
		interior,
		packages,
		base: vehicle.basePrice,
		options,
		delivery,
		registration,
		documentation,
		totalBeforeTax: vehicle.basePrice + options + delivery + registration + documentation
	};
}
function configurationLine(quote) {
	const packs = quote.packages.length ? quote.packages.map((item) => item.name).join(", ") : "No packages";
	return `${quote.exterior.name} exterior · ${quote.interior.name} interior · ${packs}`;
}
//#endregion
export { writeConfig as i, quoteVehicle as n, readConfig as r, configurationLine as t };
