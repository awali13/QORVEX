import { C as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as Kicker } from "./router-CfsKt9Uf.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/about-Cvg7ZgSS.js
var import_jsx_runtime = require_jsx_runtime();
function AboutPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "bg-ink pt-16",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
			src: "/vehicles/xt-front.jpg",
			alt: "QORVEX X-T on a mountain road, used as the house portrait.",
			className: "h-[58svh] w-full object-cover object-center"
		})
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-3xl px-5 py-16",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: "The House" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-3 font-display text-6xl",
				children: "Born to Lead."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 space-y-5 text-muted",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "QORVEX is a short line of automobiles: the V9 electric grand tourer, the V09 electric grand SUV, the X-T six-wheel diesel, and AWK Soul, a supercharged V12 hypercar. The point is not a ladder of trims. Each car has a job." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "V9 and V09 share a hydraulic fully active suspension and a battery-electric drivetrain, with different bodies and different outputs. The X-T does not follow them. It keeps a V8 diesel and six wheels because the work is different. AWK Soul does not follow them either. It is a circuit hypercar, not a softened version of the coupe." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "The photographs on this site are the supplied studies. Wide boards are shown whole. Colours you can select in the configurator are labelled as samples when they are not the finish in the photograph. Prices are indicative estimates in US dollars. They are not a quote." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "A reservation on this website holds a configuration for 24 hours in your browser, then opens a demonstration checkout. The demonstration does not take payment. WhatsApp alerts to the house are sent only when the WhatsApp Business Platform is configured on the server." })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-10 flex flex-wrap gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/collection",
					className: "inline-flex min-h-11 items-center bg-ivory px-5 text-xs tracking-widest text-obsidian uppercase",
					children: "The collection"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/enquiries",
					className: "inline-flex min-h-11 items-center border border-ivory/30 px-5 text-xs tracking-widest uppercase",
					children: "Enquire"
				})]
			})
		]
	})] });
}
//#endregion
export { AboutPage as component };
