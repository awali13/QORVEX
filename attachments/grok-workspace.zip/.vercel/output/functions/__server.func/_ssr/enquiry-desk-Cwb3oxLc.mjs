import { i as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, Z as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as useServerFn, t as notifyDesk } from "./notify-TPvQyZQV.mjs";
import { f as buttonClass, g as formatWhen, m as fieldClass, s as Field, u as Note, y as vehicles } from "./router-CfsKt9Uf.mjs";
import { n as listEnquiries, s as saveEnquiry } from "./reservations-DH_WAOy6.mjs";
import { t as digits } from "./validate-B75Uj1h4.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/enquiry-desk-Cwb3oxLc.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var topics = [
	"Model question",
	"Reservation",
	"Ownership",
	"Press",
	"Other"
];
function EnquiryDesk({ heading, lede }) {
	const send = useServerFn(notifyDesk);
	const [name, setName] = (0, import_react.useState)("");
	const [email, setEmail] = (0, import_react.useState)("");
	const [phone, setPhone] = (0, import_react.useState)("");
	const [topic, setTopic] = (0, import_react.useState)(topics[0] ?? "Model question");
	const [vehicle, setVehicle] = (0, import_react.useState)("General");
	const [message, setMessage] = (0, import_react.useState)("");
	const [errors, setErrors] = (0, import_react.useState)({});
	const [pending, setPending] = (0, import_react.useState)(false);
	const [items, setItems] = (0, import_react.useState)([]);
	const [banner, setBanner] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		setItems(listEnquiries());
	}, []);
	async function onSubmit(event) {
		event.preventDefault();
		const next = {};
		if (name.trim().length < 2) next.name = "Enter your name.";
		if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) next.email = "Enter a valid email.";
		if (digits(phone).length < 7) next.phone = "Enter a phone number with at least 7 digits.";
		if (message.trim().length < 8) next.message = "Write a short message, at least a sentence.";
		setErrors(next);
		if (Object.keys(next).length) return;
		setPending(true);
		let whatsapp = "failed";
		let whatsappDetail = "The notification service did not respond.";
		let createdAt = Date.now();
		try {
			const result = await send({ data: {
				kind: "enquiry",
				name: name.trim(),
				email: email.trim(),
				phone: phone.trim(),
				topic,
				vehicle: vehicle === "General" ? "" : vehicle,
				message: message.trim()
			} });
			createdAt = result.acceptedAt;
			whatsapp = result.state;
			whatsappDetail = result.detail;
		} catch {
			whatsapp = "failed";
		}
		const enquiry = {
			id: `ENQ-${createdAt.toString(36).toUpperCase()}`,
			createdAt,
			name: name.trim(),
			email: email.trim(),
			phone: phone.trim(),
			topic,
			vehicle,
			message: message.trim(),
			whatsapp,
			whatsappDetail
		};
		saveEnquiry(enquiry);
		setItems(listEnquiries());
		setMessage("");
		setBanner(whatsapp === "sent" ? "Enquiry saved on this device. WhatsApp accepted the notification." : `Enquiry saved on this device. ${whatsappDetail}`);
		setPending(false);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto grid max-w-7xl gap-12 px-5 pt-28 pb-24 lg:grid-cols-12",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "lg:col-span-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs tracking-widest text-champagne uppercase",
					children: "Desk"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-3 font-display text-5xl sm:text-6xl",
					children: heading
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-muted",
					children: lede
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Note, { children: "Sample desk for this preview: enquiries@qorvex.example. Messages stay in this browser. A WhatsApp Business notification is attempted only when server credentials are set. No payment is discussed or taken here." })
				}),
				items.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-8 space-y-4",
					children: items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "border-t border-line pt-4 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-xs tracking-widest text-faint uppercase",
								children: [
									item.topic,
									" · ",
									formatWhen(item.createdAt)
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2",
								children: item.message
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-1 text-muted",
								children: [
									item.vehicle,
									" · WhatsApp ",
									item.whatsapp.replaceAll("_", " ")
								]
							})
						]
					}, item.id))
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-8 text-sm text-faint",
					children: "No enquiries stored on this device yet."
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "space-y-5 lg:col-span-7",
			onSubmit,
			noValidate: true,
			children: [
				banner ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Note, { children: banner }) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-5 sm:grid-cols-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							id: "name",
							label: "Name",
							error: errors.name,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								id: "name",
								className: fieldClass,
								autoComplete: "name",
								value: name,
								onChange: (event) => setName(event.target.value)
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							id: "email",
							label: "Email",
							error: errors.email,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								id: "email",
								type: "email",
								className: fieldClass,
								autoComplete: "email",
								value: email,
								onChange: (event) => setEmail(event.target.value)
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							id: "phone",
							label: "Phone",
							error: errors.phone,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								id: "phone",
								type: "tel",
								className: fieldClass,
								autoComplete: "tel",
								value: phone,
								onChange: (event) => setPhone(event.target.value)
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							id: "topic",
							label: "Topic",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
								id: "topic",
								className: fieldClass,
								value: topic,
								onChange: (event) => setTopic(event.target.value),
								children: topics.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: item }, item))
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "sm:col-span-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								id: "vehicle",
								label: "Vehicle",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									id: "vehicle",
									className: fieldClass,
									value: vehicle,
									onChange: (event) => setVehicle(event.target.value),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "General" }), vehicles.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: item.name }, item.slug))]
								})
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "sm:col-span-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								id: "message",
								label: "Message",
								error: errors.message,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
									id: "message",
									rows: 6,
									className: fieldClass,
									value: message,
									onChange: (event) => setMessage(event.target.value)
								})
							})
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "submit",
					className: buttonClass("solid"),
					disabled: pending,
					children: pending ? "Sending…" : "Send enquiry"
				})
			]
		})]
	});
}
//#endregion
export { EnquiryDesk as t };
