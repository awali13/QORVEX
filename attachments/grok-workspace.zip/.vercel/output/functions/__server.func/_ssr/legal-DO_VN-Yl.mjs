import { C as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/legal-DO_VN-Yl.js
var import_jsx_runtime = require_jsx_runtime();
function Legal({ title, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "mx-auto max-w-3xl px-5 pt-28 pb-24",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "border border-champagne/40 bg-panel px-4 py-3 text-sm text-champagne-2",
				children: "Sample policy for this website preview. It is not legal advice and it has not been reviewed as a QORVEX customer contract. Replace it before any real sale."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-8 font-display text-5xl sm:text-6xl",
				children: title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-8 space-y-4 text-sm leading-relaxed text-muted",
				children
			})
		]
	});
}
//#endregion
export { Legal as t };
