//#region node_modules/.nitro/vite/services/ssr/assets/validate-B75Uj1h4.js
var emailOk = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
function digits(value) {
	return value.replace(/\D/g, "");
}
function validateCustomer(input, consent) {
	const errors = {};
	if (input.fullName.trim().length < 2) errors.fullName = "Enter the full name the reservation should use.";
	if (!emailOk.test(input.email.trim())) errors.email = "Enter a valid email address.";
	if (digits(input.phone).length < 7) errors.phone = "Enter a phone number with at least 7 digits.";
	if (input.country.trim().length < 2) errors.country = "Enter a country.";
	if (input.city.trim().length < 2) errors.city = "Enter a city.";
	if (input.address.trim().length < 8) errors.address = "Enter the full delivery address.";
	if (!consent) errors.consent = "Confirm the hold, the estimates, and that this preview takes no payment.";
	return errors;
}
function emptyCustomer() {
	return {
		fullName: "",
		email: "",
		phone: "",
		country: "",
		city: "",
		address: ""
	};
}
//#endregion
export { emptyCustomer as n, validateCustomer as r, digits as t };
