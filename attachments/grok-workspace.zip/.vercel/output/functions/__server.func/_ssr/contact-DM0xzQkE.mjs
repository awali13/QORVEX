import { C as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as EnquiryDesk } from "./enquiry-desk-Cwb3oxLc.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/contact-DM0xzQkE.js
var import_jsx_runtime = require_jsx_runtime();
function ContactPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EnquiryDesk, {
		heading: "Contact.",
		lede: "There is no public studio address in the material supplied for this site. Use the form. The sample inbox below is for the preview only and is not a monitored QORVEX mailbox."
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto -mt-10 max-w-7xl px-5 pb-16 text-sm text-muted",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Sample preview inbox: enquiries@qorvex.example" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2",
				children: "Sample preview phone: +1 000 000 0190 — not a live line."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-4",
				children: [
					"Reservations already started live under ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/reservations",
						className: "text-champagne-2",
						children: "Your reservations"
					}),
					". Policies: ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/privacy",
						className: "text-champagne-2",
						children: "Privacy"
					}),
					",",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/terms",
						className: "text-champagne-2",
						children: "Terms"
					}),
					"."
				]
			})
		]
	})] });
}
//#endregion
export { ContactPage as component };
