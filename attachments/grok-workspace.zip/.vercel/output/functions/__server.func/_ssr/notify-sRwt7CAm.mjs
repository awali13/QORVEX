import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
import { a as object, i as number, n as discriminatedUnion, o as string, r as literal, t as _enum } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/notify-sRwt7CAm.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var customer = object({
	fullName: string().trim().min(2).max(120),
	email: string().trim().email().max(160),
	phone: string().trim().min(7).max(40),
	country: string().trim().min(2).max(80),
	city: string().trim().min(2).max(80),
	address: string().trim().min(8).max(240)
});
var payload = discriminatedUnion("kind", [
	object({
		kind: literal("reservation"),
		reference: string().trim().min(4).max(24),
		vehicleName: string().trim().min(2).max(80),
		configuration: string().trim().min(2).max(400),
		totalBeforeTax: number().int().nonnegative().max(2e7),
		customer
	}),
	object({
		kind: literal("cancel"),
		reference: string().trim().min(4).max(24),
		vehicleName: string().trim().min(2).max(80),
		customerName: string().trim().min(2).max(120)
	}),
	object({
		kind: literal("purchase"),
		phase: _enum(["opened", "demo_recorded"]),
		reference: string().trim().min(4).max(24),
		vehicleName: string().trim().min(2).max(80),
		totalBeforeTax: number().int().nonnegative().max(2e7),
		customerName: string().trim().min(2).max(120)
	}),
	object({
		kind: literal("enquiry"),
		name: string().trim().min(2).max(120),
		email: string().trim().email().max(160),
		phone: string().trim().min(7).max(40),
		topic: string().trim().min(2).max(80),
		vehicle: string().trim().max(80),
		message: string().trim().min(8).max(2e3)
	})
]);
var hits = [];
function rateLimited() {
	const now = Date.now();
	while (hits.length && now - hits[0] > 6e4) hits.shift();
	if (hits.length >= 8) return true;
	hits.push(now);
	return false;
}
function money(value) {
	return new Intl.NumberFormat("en-US", {
		style: "currency",
		currency: "USD",
		maximumFractionDigits: 0
	}).format(value);
}
function messagesFor(data) {
	if (data.kind === "reservation") {
		const who = `${data.customer.fullName} · ${data.customer.email} · ${data.customer.phone}`;
		const where = `${data.customer.address}, ${data.customer.city}, ${data.customer.country}`;
		const price = `${money(data.totalBeforeTax)} indicative total before local tax`;
		return [
			{
				event: "booking_received",
				body: `QORVEX booking received\nRef ${data.reference}\n${data.vehicleName}\n${data.configuration}\n${price}\n${who}\n${where}`
			},
			{
				event: "booking_confirmation",
				body: `QORVEX booking confirmation\nRef ${data.reference} is logged for ${data.customer.fullName}.\n${data.vehicleName}. ${data.configuration}.\nThis is a website reservation, not a paid order.`
			},
			{
				event: "waiting_period",
				body: `QORVEX 24-hour hold\nRef ${data.reference} stays in a waiting period for 24 hours before the purchase stage opens.\nNo payment has been taken.`
			}
		];
	}
	if (data.kind === "cancel") return [{
		event: "waiting_period",
		body: `QORVEX hold update\nRef ${data.reference} was cancelled by ${data.customerName} during the reservation flow.\n${data.vehicleName}. No payment was taken.`
	}];
	if (data.kind === "purchase") return [{
		event: "purchase_stage",
		body: `QORVEX purchase-stage update\n${data.phase === "opened" ? `Purchase stage opened for ref ${data.reference}. The checkout is a demonstration. No payment has been received.` : `Demonstration checkout recorded for ref ${data.reference}. No card was charged and no payment was received.`}\n${data.vehicleName} · ${data.customerName} · ${money(data.totalBeforeTax)} indicative, before tax.`
	}];
	return [{
		event: "enquiry",
		body: `QORVEX enquiry\n${data.topic}${data.vehicle ? ` · ${data.vehicle}` : ""}\n${data.name} · ${data.email} · ${data.phone}\n${data.message}`
	}];
}
async function postWhatsApp(token, phoneId, to, body) {
	const response = await fetch(`https://graph.facebook.com/v21.0/${phoneId}/messages`, {
		method: "POST",
		headers: {
			Authorization: `Bearer ${token}`,
			"Content-Type": "application/json"
		},
		body: JSON.stringify({
			messaging_product: "whatsapp",
			recipient_type: "individual",
			to,
			type: "text",
			text: {
				preview_url: false,
				body
			}
		}),
		signal: AbortSignal.timeout(12e3)
	});
	if (!response.ok) {
		console.error("[qorvex] WhatsApp API status", response.status);
		return false;
	}
	return true;
}
var notifyDesk_createServerFn_handler = createServerRpc({
	id: "d0cd53ed69ed2e389529d87d46ac652dbe2aae0925e6fe02a268178880b512cf",
	name: "notifyDesk",
	filename: "src/lib/notify.ts"
}, (opts) => notifyDesk.__executeServer(opts));
var notifyDesk = createServerFn({ method: "POST" }).validator((input) => payload.parse(input)).handler(notifyDesk_createServerFn_handler, async ({ data }) => {
	const acceptedAt = Date.now();
	const token = process.env.WHATSAPP_ACCESS_TOKEN;
	const phoneId = process.env.WHATSAPP_PHONE_NUMBER_ID;
	const to = process.env.WHATSAPP_NOTIFY_TO?.replace(/[^\d]/g, "");
	if (!token || !phoneId || !to) return {
		acceptedAt,
		state: "not_configured",
		detail: "WhatsApp Business is not configured. Set WHATSAPP_ACCESS_TOKEN, WHATSAPP_PHONE_NUMBER_ID and WHATSAPP_NOTIFY_TO on the server. Nothing was sent."
	};
	if (rateLimited()) return {
		acceptedAt,
		state: "rate_limited",
		detail: "Too many notification attempts in a short time. Nothing further was sent."
	};
	const messages = messagesFor(data);
	let sent = 0;
	for (const message of messages) try {
		if (await postWhatsApp(token, phoneId, to, message.body)) sent += 1;
	} catch (error) {
		console.error("[qorvex] WhatsApp request failed", error instanceof Error ? error.name : "error");
	}
	if (sent === messages.length) return {
		acceptedAt,
		state: "sent",
		detail: `${sent} WhatsApp message${sent === 1 ? "" : "s"} accepted by the API.`
	};
	if (sent === 0) return {
		acceptedAt,
		state: "failed",
		detail: "The WhatsApp API did not accept the message. Check the token, phone number ID, and recipient."
	};
	return {
		acceptedAt,
		state: "partial",
		detail: `${sent} of ${messages.length} WhatsApp messages were accepted.`
	};
});
//#endregion
export { notifyDesk_createServerFn_handler };
