import { C as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as Kicker, l as Money, u as Note, y as vehicles } from "./router-CfsKt9Uf.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/collection-qz1j4REg.js
var import_jsx_runtime = require_jsx_runtime();
function Collection() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-7xl px-5 pt-28 pb-24",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: "Collection" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-3 max-w-3xl font-display text-5xl sm:text-7xl",
				children: "The cars QORVEX will talk about."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-5 max-w-2xl text-muted",
				children: "Four current models. Specifications marked on each page come from the model sheet. Colours, packages and prices are sample figures for this preview."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-12 grid gap-10",
				children: vehicles.map((vehicle) => {
					const shot = vehicle.shots[0];
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "grid gap-6 border-t border-line pt-8 md:grid-cols-12",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/vehicles/$slug",
							params: { slug: vehicle.slug },
							className: "bg-ink md:col-span-7",
							children: shot ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: shot.src,
								alt: shot.alt,
								width: shot.width,
								height: shot.height,
								className: shot.frame === "banner" ? "mx-auto block h-auto w-full max-w-4xl object-contain" : "aspect-[3/2] w-full object-cover"
							}) : null
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col justify-center md:col-span-5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs tracking-widest text-champagne uppercase",
									children: vehicle.category
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "mt-2 font-display text-5xl",
									children: vehicle.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-3 text-muted",
									children: vehicle.summary
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-4 text-sm text-faint",
									children: ["Indicative from ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Money, { value: vehicle.basePrice })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-6 flex flex-wrap gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: "/vehicles/$slug",
										params: { slug: vehicle.slug },
										className: "inline-flex min-h-11 items-center bg-ivory px-5 text-xs tracking-widest text-obsidian uppercase",
										children: "Details"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: "/configure/$slug",
										params: { slug: vehicle.slug },
										className: "inline-flex min-h-11 items-center border border-ivory/30 px-5 text-xs tracking-widest uppercase",
										children: "Configure"
									})]
								})
							]
						})]
					}, vehicle.slug);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-16 overflow-x-auto border border-line",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full min-w-[44rem] text-left text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("caption", {
							className: "sr-only",
							children: "Collection comparison"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
							className: "bg-panel text-xs tracking-widest uppercase text-faint",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 font-medium",
								children: " "
							}), vehicles.map((vehicle) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 font-medium text-ivory",
								children: vehicle.code
							}, vehicle.slug))] })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: [
							["Category", (v) => v.category],
							["Powertrain", (v) => v.specs.find((s) => s.label === "Powertrain")?.value ?? "—"],
							["Power", (v) => v.specs.find((s) => s.label === "Power")?.value ?? "Not stated"],
							["Top speed", (v) => v.specs.find((s) => s.label === "Top speed")?.value ?? "Not stated"],
							["Range", (v) => v.specs.find((s) => s.label === "Range")?.value ?? "Not stated"]
						].map(([label, read]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "border-t border-line",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 font-normal text-faint",
								children: label
							}), vehicles.map((vehicle) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-3",
								children: read(vehicle)
							}, vehicle.slug))]
						}, label)) })
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Note, { children: "Where a figure is “Not stated”, it was not in the written sheet for this build. It has been left blank on purpose. Indicative prices are sample catalogue numbers, not a QORVEX quote." })
			})
		]
	});
}
//#endregion
export { Collection as component };
