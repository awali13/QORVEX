import { C as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as Legal } from "./legal-DO_VN-Yl.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/privacy-LSQoNtJA.js
var import_jsx_runtime = require_jsx_runtime();
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Legal, {
	title: "Privacy",
	children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "This preview keeps reservations and enquiries in your browser (local storage). They are not written to a shared database. Another person on another device cannot see them. Clearing the browser removes them." }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "When you submit a reservation, cancellation, purchase-stage event, or enquiry, the details you typed are sent to the site server so it can try a WhatsApp Business message to a single house number. That number is set with server environment variables and is never chosen by the page. If those variables are missing, the server returns without sending anything." }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "The server is not designed to store that message. Do not type card numbers, identity documents, or passwords into any field. This preview does not ask for them." }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Sample contact addresses published on the contact page are not live inboxes. Do not send sensitive information to enquiries@qorvex.example." })
	]
});
//#endregion
export { SplitComponent as component };
