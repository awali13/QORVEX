import { i as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, Z as require_react, b as Link, x as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as useServerFn, t as notifyDesk } from "./notify-TPvQyZQV.mjs";
import { _ as getVehicle, c as Kicker, f as buttonClass, l as Money, m as fieldClass, r as Route$1, s as Field, u as Note } from "./router-CfsKt9Uf.mjs";
import { c as saveReservation, i as makeReference } from "./reservations-DH_WAOy6.mjs";
import { n as emptyCustomer, r as validateCustomer } from "./validate-B75Uj1h4.mjs";
import { n as quoteVehicle, r as readConfig, t as configurationLine } from "./pricing-BgasnRnJ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/reserve._slug-D-bgJzKm.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ReservePage() {
	const { slug } = Route$1.useParams();
	const vehicle = getVehicle(slug);
	if (!vehicle) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReserveForm, { vehicle });
}
function ReserveForm({ vehicle }) {
	const navigate = useNavigate();
	const send = useServerFn(notifyDesk);
	const [customer, setCustomer] = (0, import_react.useState)(emptyCustomer);
	const [consent, setConsent] = (0, import_react.useState)(false);
	const [errors, setErrors] = (0, import_react.useState)({});
	const [pending, setPending] = (0, import_react.useState)(false);
	const [configReady, setConfigReady] = (0, import_react.useState)(false);
	const [config, setConfig] = (0, import_react.useState)(() => ({
		exteriorId: vehicle.exteriors[0]?.id ?? "",
		interiorId: vehicle.interiors[0]?.id ?? "",
		packageIds: []
	}));
	(0, import_react.useEffect)(() => {
		setConfig(readConfig(vehicle));
		setConfigReady(true);
	}, [vehicle]);
	const quote = (0, import_react.useMemo)(() => quoteVehicle(vehicle, config), [vehicle, config]);
	const line = configurationLine(quote);
	const shot = vehicle.shots[0];
	function set(key, value) {
		setCustomer((current) => ({
			...current,
			[key]: value
		}));
	}
	async function onSubmit(event) {
		event.preventDefault();
		const nextErrors = validateCustomer(customer, consent);
		setErrors(nextErrors);
		if (Object.keys(nextErrors).length) return;
		setPending(true);
		const reference = makeReference();
		let acceptedAt = Date.now();
		let whatsappBooking = "failed";
		let whatsappDetail = "The notification service did not respond.";
		try {
			const result = await send({ data: {
				kind: "reservation",
				reference,
				vehicleName: vehicle.name,
				configuration: line,
				totalBeforeTax: quote.totalBeforeTax,
				customer: {
					fullName: customer.fullName.trim(),
					email: customer.email.trim(),
					phone: customer.phone.trim(),
					country: customer.country.trim(),
					city: customer.city.trim(),
					address: customer.address.trim()
				}
			} });
			acceptedAt = result.acceptedAt;
			whatsappBooking = result.state;
			whatsappDetail = result.detail;
		} catch {
			whatsappBooking = "failed";
			whatsappDetail = "The notification service did not respond. The reservation is still saved on this device.";
		}
		saveReservation({
			reference,
			createdAt: acceptedAt,
			vehicleSlug: vehicle.slug,
			vehicleName: vehicle.name,
			configuration: line,
			exteriorName: quote.exterior.name,
			interiorName: quote.interior.name,
			packageNames: quote.packages.map((item) => item.name),
			pricing: {
				base: quote.base,
				options: quote.options,
				delivery: quote.delivery,
				registration: quote.registration,
				documentation: quote.documentation,
				totalBeforeTax: quote.totalBeforeTax
			},
			customer: {
				fullName: customer.fullName.trim(),
				email: customer.email.trim(),
				phone: customer.phone.trim(),
				country: customer.country.trim(),
				city: customer.city.trim(),
				address: customer.address.trim()
			},
			whatsappBooking,
			whatsappDetail
		});
		setPending(false);
		navigate({
			to: "/confirmation/$ref",
			params: { ref: reference }
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto grid max-w-7xl gap-10 px-5 pt-28 pb-24 lg:grid-cols-12",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "lg:col-span-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: "Reservation" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-3 font-display text-5xl",
					children: "Review, then hold."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-muted",
					children: "Submitting starts a 24-hour waiting period. The purchase stage stays closed until that hold ends. Nothing is charged."
				}),
				!configReady ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-6 text-sm text-faint",
					children: "Reading your configuration…"
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6 bg-ink",
					children: shot ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: shot.src,
						alt: shot.alt,
						className: shot.frame === "banner" ? "mx-auto block h-auto w-full max-w-4xl object-contain" : "aspect-[3/2] w-full object-cover"
					}) : null
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 border border-line p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs tracking-widest text-faint uppercase",
							children: vehicle.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2",
							children: line
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
							className: "mt-4 space-y-2 text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
									label: "Vehicle estimate",
									value: quote.base
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
									label: "Sample options",
									value: quote.options
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
									label: "Delivery estimate",
									value: quote.delivery
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
									label: "Registration estimate",
									value: quote.registration
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
									label: "Documentation estimate",
									value: quote.documentation
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "flex justify-between gap-4 border-t border-line pt-2 text-base",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Before local tax" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Money, { value: quote.totalBeforeTax })]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-sm text-faint",
							children: "Tax is not included and is not estimated. Not an invoice."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/configure/$slug",
							params: { slug: vehicle.slug },
							className: "mt-4 inline-flex min-h-11 items-center text-xs tracking-widest text-champagne uppercase",
							children: "Edit configuration"
						})
					]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "space-y-5 lg:col-span-7",
			onSubmit,
			noValidate: true,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Note, { children: "Sample choices and sample fees travel with this reservation. A live QORVEX desk would confirm them before any purchase. WhatsApp alerts are sent only when the Business Platform credentials are configured on the server." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-5 sm:grid-cols-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							id: "fullName",
							label: "Full name",
							error: errors.fullName,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								id: "fullName",
								autoComplete: "name",
								className: fieldClass,
								value: customer.fullName,
								"aria-invalid": Boolean(errors.fullName),
								"aria-describedby": errors.fullName ? "fullName-error" : void 0,
								onChange: (event) => set("fullName", event.target.value)
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							id: "email",
							label: "Email",
							error: errors.email,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								id: "email",
								type: "email",
								autoComplete: "email",
								className: fieldClass,
								value: customer.email,
								"aria-invalid": Boolean(errors.email),
								"aria-describedby": errors.email ? "email-error" : void 0,
								onChange: (event) => set("email", event.target.value)
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							id: "phone",
							label: "Phone",
							error: errors.phone,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								id: "phone",
								type: "tel",
								autoComplete: "tel",
								className: fieldClass,
								value: customer.phone,
								"aria-invalid": Boolean(errors.phone),
								"aria-describedby": errors.phone ? "phone-error" : void 0,
								onChange: (event) => set("phone", event.target.value)
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							id: "country",
							label: "Country",
							error: errors.country,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								id: "country",
								autoComplete: "country-name",
								className: fieldClass,
								value: customer.country,
								"aria-invalid": Boolean(errors.country),
								"aria-describedby": errors.country ? "country-error" : void 0,
								onChange: (event) => set("country", event.target.value)
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							id: "city",
							label: "City",
							error: errors.city,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								id: "city",
								autoComplete: "address-level2",
								className: fieldClass,
								value: customer.city,
								"aria-invalid": Boolean(errors.city),
								"aria-describedby": errors.city ? "city-error" : void 0,
								onChange: (event) => set("city", event.target.value)
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "sm:col-span-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								id: "address",
								label: "Delivery address",
								error: errors.address,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
									id: "address",
									autoComplete: "street-address",
									rows: 3,
									className: fieldClass,
									value: customer.address,
									"aria-invalid": Boolean(errors.address),
									"aria-describedby": errors.address ? "address-error" : void 0,
									onChange: (event) => set("address", event.target.value)
								})
							})
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex gap-3 text-sm text-muted",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "checkbox",
						className: "mt-1 size-4 accent-champagne",
						checked: consent,
						onChange: (event) => setConsent(event.target.checked)
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "I understand this starts a 24-hour hold, that prices and fees shown are estimates, and that this website does not take payment." })]
				}),
				errors.consent ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-champagne-2",
					children: errors.consent
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "submit",
					className: buttonClass("solid"),
					disabled: pending,
					children: pending ? "Holding the car…" : "Submit reservation"
				})
			]
		})]
	});
}
function Row({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
		className: "flex justify-between gap-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Money, { value })]
	});
}
//#endregion
export { ReservePage as component };
