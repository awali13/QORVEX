import { C as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/vehicles._slug-Dw920bY9.js
var import_jsx_runtime = require_jsx_runtime();
function Missing() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-3xl px-5 pt-32 pb-24",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-5xl",
			children: "That model is not in the line."
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/collection",
			className: "mt-6 inline-flex min-h-11 items-center text-xs tracking-widest text-champagne uppercase",
			children: "Back to the collection"
		})]
	});
}
//#endregion
export { Missing as notFoundComponent };
