//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DRnmJMQm.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/about",
			"/cancellation",
			"/collection",
			"/contact",
			"/enquiries",
			"/privacy",
			"/refund",
			"/reservations",
			"/terms",
			"/checkout/$ref",
			"/configure/$slug",
			"/confirmation/$ref",
			"/reserve/$slug",
			"/vehicles/$slug"
		],
		preloads: [
			"/assets/index--GxaGCnf.js",
			"/assets/jsx-runtime-BkSabwWG.js",
			"/assets/link-C_uFB37a.js",
			"/assets/redirect-D2YulXhr.js",
			"/assets/site-D_5aY9Po.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index--GxaGCnf.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-CtqjrOQG.js"]
	},
	"/about": {
		filePath: "/workspace/src/routes/about.tsx",
		children: void 0,
		preloads: ["/assets/about-DaOIADoD.js"]
	},
	"/cancellation": {
		filePath: "/workspace/src/routes/cancellation.tsx",
		children: void 0,
		preloads: ["/assets/cancellation-DiarCxgY.js", "/assets/legal-BI1DhiMr.js"]
	},
	"/collection": {
		filePath: "/workspace/src/routes/collection.tsx",
		children: void 0,
		preloads: ["/assets/collection-RkOxGJDj.js"]
	},
	"/contact": {
		filePath: "/workspace/src/routes/contact.tsx",
		children: void 0,
		preloads: ["/assets/contact-CLeDdo-d.js", "/assets/enquiry-desk-CRz2i8Fo.js"]
	},
	"/enquiries": {
		filePath: "/workspace/src/routes/enquiries.tsx",
		children: void 0,
		preloads: ["/assets/enquiries-CPnc2Ltl.js", "/assets/enquiry-desk-CRz2i8Fo.js"]
	},
	"/privacy": {
		filePath: "/workspace/src/routes/privacy.tsx",
		children: void 0,
		preloads: ["/assets/privacy-C0uPSnUS.js", "/assets/legal-BI1DhiMr.js"]
	},
	"/refund": {
		filePath: "/workspace/src/routes/refund.tsx",
		children: void 0,
		preloads: ["/assets/refund-Ce9r_vrv.js", "/assets/legal-BI1DhiMr.js"]
	},
	"/reservations": {
		filePath: "/workspace/src/routes/reservations.tsx",
		children: void 0,
		preloads: ["/assets/reservations-XhvocmRO.js", "/assets/reservations-DKKxo4WP.js"]
	},
	"/terms": {
		filePath: "/workspace/src/routes/terms.tsx",
		children: void 0,
		preloads: ["/assets/terms-nk5-6T42.js", "/assets/legal-BI1DhiMr.js"]
	},
	"/checkout/$ref": {
		filePath: "/workspace/src/routes/checkout.$ref.tsx",
		children: void 0,
		preloads: [
			"/assets/checkout._ref-Cv8pH6eM.js",
			"/assets/notify-DRVj1cWh.js",
			"/assets/reservations-DKKxo4WP.js",
			"/assets/validate-gStv2X8T.js"
		]
	},
	"/configure/$slug": {
		filePath: "/workspace/src/routes/configure.$slug.tsx",
		children: void 0,
		preloads: ["/assets/configure._slug-BUVkW-h2.js", "/assets/pricing-Dm-4Se0H.js"]
	},
	"/confirmation/$ref": {
		filePath: "/workspace/src/routes/confirmation.$ref.tsx",
		children: void 0,
		preloads: [
			"/assets/confirmation._ref-DW4_YxyE.js",
			"/assets/notify-DRVj1cWh.js",
			"/assets/reservations-DKKxo4WP.js"
		]
	},
	"/reserve/$slug": {
		filePath: "/workspace/src/routes/reserve.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/reserve._slug-dbaEao7H.js",
			"/assets/notify-DRVj1cWh.js",
			"/assets/reservations-DKKxo4WP.js",
			"/assets/validate-gStv2X8T.js",
			"/assets/pricing-Dm-4Se0H.js"
		]
	},
	"/vehicles/$slug": {
		filePath: "/workspace/src/routes/vehicles.$slug.tsx",
		children: void 0,
		preloads: ["/assets/vehicles._slug-BDgSuNUL.js", "/assets/vehicles._slug-CRyyQkK-.js"]
	}
} });
//#endregion
export { tsrStartManifest };
