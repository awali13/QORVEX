import { chromium } from "playwright";
import { mkdir } from "node:fs/promises";

const browser = await chromium.launch({
  headless: true,
  args: ["--no-sandbox", "--disable-dev-shm-usage"],
});
const page = await browser.newPage({
  viewport: { width: 1200, height: 630 },
  deviceScaleFactor: 1,
});
await page.goto("file:///workspace/.grok/og-specimens.html", { waitUntil: "networkidle" });
await page.evaluate(() => document.fonts.ready);
await mkdir("/workspace/.grok/specimens", { recursive: true });
const cards = page.locator(".card");
const n = await cards.count();
for (let i = 0; i < n; i++) {
  const label = (await cards.nth(i).locator(".label").innerText()).replace(/\s+/g, "-").toLowerCase();
  await cards.nth(i).screenshot({ path: `/workspace/.grok/specimens/${label}.png` });
}
await browser.close();
console.log("wrote", n);
